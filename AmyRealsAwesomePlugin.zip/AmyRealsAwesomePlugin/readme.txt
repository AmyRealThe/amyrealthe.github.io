place the files in the " program files (x86) / common files / VST3 " path :)
idk wgat the lib or exp files do huuuuh just the vst3 should do it honestly

so basically theres 2 bitcrushers that do the same thing. but the way I do my masters I like to have
2 layers of bitcrush to have a little more brightness in the high end so I like added 2 instead of one
to recreate that effect in one plugin instead of two

huuuh theres also a clipper. pretty straightforward. the gain controls the total gain of the thing and then
the clip parameter changes the ceiling of the clip #yooo #wooo and then the smooth changes the curve of
the thingy  yknow. the like attack kinda it makes it more smoove I guess

then the reverb yeah its a reverb. just make sure the wet knob is all the way down if you dont want it
because the plugin opens with the wet maxxed out for some reason ill try to fix that

im working on more features so expect updates for this!!!!

anyways thats it. this plugin is free to be distributed for free if you feel like it idc theres no copyright for 
shit I made this myself in a couple days to put it on my website have fun who cares whatever
ill literally shoot myself on the spot

THATS ALL FOR ME!!!!! ENJOY :D

here's the script of the lego movie





---------------------------------------------------------





[Universal Pictures fanfare]
[We see deep within the Lego mountain Vitruvius is guarding something when he senses someone approaching]
Vitruvius: He is coming. Cover your butt.
Guard: Cover the what?
[Lord Business bursts in killing the guards and does an evil laugh]
Lord Business: Vitruvius!
Vitruvius: Lord Business.
Lord Business: You've hidden the Kragle well, old man. [turning to his army of Lego robots] Robots, destroy him!
Robots: Yes, Lord Business.
Vitruvius: Your robots are no match for a Master Builder! For I see everything! (a red laser pointer is shoots at the Vitruvius eyes to blinded) Unh My eyes! Ow!
Lord Business: The Kragle the most powerful super weapon in the universe is mine! Oh the Kragle! (evil laugh) Now my evil power will be unlimited! Can you feel me?
Robot (monotone): I can feel you.
[his robots start carrying the Kragle away]
Lord Business: Whoo! Nothing’s gonna stop me now!
Vitruvius: (weak) Wait! There was a prophecy.
Lord Business: (grumbles, complaints) Oh, now there's a prophecy. [he turns to Vitruvius]
Vitruvius: (cont'd) About the Piece of Resistance.
Lord Business: Oh, yes, the supposed missing Piece of Resistance that can somehow magically disarm the Kragle. Gimme a break!
[Vitruvius rises and turns to face Lord Business, suddenly his eyes shine brightly]
Vitruvius: One day a talented lass or fellow, a Special one with face of yellow, will make the Piece of Resistance found from its hiding refuge underground. And with a noble army at the helm, this Master Builder will thwart the Kragle and save the realm, and be the greatest, most interesting, most important person of all times. All this is true, because it rhymes.
Lord Business: Oh, well. That was a great inspiring legend that you made up. [suddenly he kicks Vitruvius with his giant robot leg off the edge of the cliff] "A Special one?" What a bunch of hippy dippy baloney!
[8 and a half years later; Emmet Brickowoski waking up in his apartment and turns off his alarm, he gets out bed yaws and stretches and walks through to his living room]
Emmet Brickowoski: Good morning, apartment! Good morning, doorway! Good morning, wall. Good morning, ceiling. Good morning, floor! Ready to start the day! [he grabs a book from a shelf] Ah, here it is! [reading from the manual] The instructions to fit in, have everybody like you, and always be happy! Step one; breathe. [Emmet inhales and exhales deeply] Okay, got that one down. Step two; greet the day, smile and say...
[We see all the Lego citizens opening their window and yelling]
Lego Citizens: Good morning, city!
[ the citizens all say good morning city]
Citizen: Good morning, city!
Citizen: Top of the Morning to you, City!
[Back to Emmet continuing with the instructions from the manual]
Emmet Brickowoski: Step three; exercise. Jumping Jacks him 'em! [he start jumping on the spot] One! Two! Three! I am so pumped up! [looking at the manual again] Step four; shower. [Emmet gets in the shower and starts washing himself] And always be sure to keep the soap out of your--! [he screams as the soap gets into his eyes] [next we see Emmet standing in front of the bathroom mirror shaving] Shave your face, brush your teeth. Comb your hair. [he laughs to himself as he brushes his hair] Wear clothes. [we see Emmet walking out of his apartment naked until he realizes] Woop! Almost forgot that one! [he turns back into his apartment and we see him quickly trying on different outfits] No. No. Uh-uh. No. Not that. Wrong. [he finally wears his construction uniform] And that's it, check. Step nine; eat a complete breakfast with all the special people in your life. [we see him sitting in his living room eating his breakfast alone, he turns to his plant] Hey, planty! What do you want to do this morning? Watch TV? Me too! [he turns on the TV showing President Business giving a presentation]
President Business: Hi, I'm President Business, president of the Octan Corporation and the World. Let's all take extra care to follow the instructions... [whispers into microphone] ...or you WILL be put to sleep. [shouting] And DON'T forget Taco Tuesday's coming next week! That's the day every rule following citizen gets a free taco and my love! Have a great day, everybody!
Emmet Brickowoski: You have a great day too, President Business. Man, he's such a cool guy. I always wanna hear more of...wait! Did he say put to sleep?! [suddenly Emmet gets distracted by the TV showing a promo of a sitcom]
TV Presenter: Tonight on "Where are my Pants?"
Actor on TV Show: Honey? Where are my pants?
[he steps out showing that he's not wearing any pants and we hear canned laughter, Emmet laughs hard at this and falls of the couch]
Emmet Brickowoski: What was I just thinking? I don't care. Step eleven; greet your neighbors. [we see Emmet walking to work and saying hi to everyone he passes] Hey, Joe.
Joe: Hey, pal.
[Joe, carrying a massive pole turns nearly hitting Emmet who quickly ducks]
Emmet Brickowoski: Woh. [Emmet spots someone he knows across the street] Hey, Surfer Dave.
Surfer Dave: Hey, brah. [walking down the street]
Emmet Brickowoski: Oh, good morning, Sharon.
Sharon: Oh, hey, pal.
[suddenly her cats starts walking out of her apartment]
Emmet Brickowoski: Oh, hey, Jasmine. Dexter. Andy! Loki, Brad, Leroy, Fluffy, Fluffy Junior, Fluffy Senior, Jeff. [Emmet gets into car and drives into work] Step twelve; obey all traffic signs and regulations. Step thirteen; enjoy popular music. [he turns on the radio]
Radio DJ: Top of the charts again, it's "Everything is Awesome".
Emmet Brickowoski: Oh, my gosh! I love this song!
[the music starts playing]
Music on Radio: Everything is awesome. Everything is cool when you're part of a team. Everything is awesome when you're living a dream.
Emmet Brickowoski: Always use the turn signal, park between the lines. [Emmet and everyone else parks in exactly the same way] Yes! Drop off dry cleaning before noon, read the headlines, don't forget to smile. [we waves and smiles to everyone as he walks down the street] Always root for the local sports team.
[Emmet and the Lego citizens shouts]
Lego Citizens: Go, sports team!
Emmet Brickowoski: Always return a compliment. [to the male Lego citizen stepping out of the coffee shop] Hey, you look nice. [everyone turns to Emmet]
Lego Citizens: So do you!
Emmet Brickowoski: Drink overpriced coffee! [inside the coffee shop he buys a coffee]
Larry The Barrista: There you go. That's thirty-seven dollars.
[Emmet looks at him for a moment before replying with excitement]
Emmet Brickowoski: Awesome!
[Emmet walks to work with his 'overpriced coffee' following the line of all the other construction workers doing exactly the same
Construction Worker: Did you see "Where are my Pants?" last night? [everyone replies at the same time] Classic episode.
[the Everything is Awesome" music continues to play in the background as the Lego construction workers get into position]
Foreman: Instructions coming in from central. Okay, it says here that anything that's weird then blow it up. [the workers start blowing up the buildings] Alright, everyone, let's make it look exactly like it does in the instruction.
Construction Worker #1: Hey, buddy! I need one-by-two keyhole!
Emmet Brickowoski: No, problem, Michael.
Construction Worker #2: Two-by-two macaroni over here.
Emmet Brickowoski: Two-by-tow macaroni flying in. Here's one, Mel.
[ Everyone chatters around]
Construction Worker #2B Cheese slopes! Cheese slopes! Come on, everybody.
Emmet Brickowoski: Roger that, Roger.
Gail; Can I get a couple of lurps over here
Emmet Brickowoski: Hey, Gail.
Construction Worker #3: Hey, guys. Watch me drill this down. [ everyone cheers.]
[they all start singing along to "Everything is Awesome"]
Emmet Brickowoski: Man, I feel so good right now! I can sing this song for hours!
[5 Hours Later; everyone at the construction site is still singing "Everything is Awesome" and it's finally coming to the end of the day]
Construction Worker #1: When you're part of a team! Wooh! Yeah! I'm going to the Sports Bar after work tonight. Who wants to eat some delicious chicken wings and get crazy?!?!?!?!
[as the other constructions workers start leave together, Emmet is left behind and tries to get their attention]
Emmet Brickowoski: Chicken wings?! I love chicken wings!
Construction Worker #2: Yeah, who wants to share a croissant with this guy?
Emmet Brickowoski: Croissant! I love croissant!
Construction Worker #3: Oh, yeah! I sure do love giant sausages!
Emmet Brickowoski: Giant sausages! No way! [nobody pays Emmet any attention as he tries to join them] You know what I love to do? Is share a meal with the special people in my life. Fred, Barry, Gail, me and you... [suddenly Emmet slams into a construction post, falls and a gust of wind blow his instruction manual out of his hand] Ah, no! Wait! Guys, wait up! Okay, I'll meet you there! [Emmet chases after his instruction manual as the wind continues to carry it off] Oh, where did it go? [he finds the manual lying on some Lego rubble] Oh, there you are. [as he retrieves the manual and turns to leave he hears something and stops] I think I heard a whoosh. [Emmet goes to find the sources of the noise] [we see a hooded figure holding a device that is searching for a relic, just as they relic is detected Emmet notices the hooded figure] Hey, pal, I hate to tell you this, but uh...I don't think you're supposed to be here. Yeah, as the rule specifically states; works light closes at six, it's a hard hat area only. [looking at the hooded figure's outfit] That's not official safety orange. [Emmet reads from his manual] If you see anything weird, report it immediately. [he grabs his phone] Well, I guess I'm gonna have to report yyyyyyyyyy... [in that moment the hooded figure removes its hood to reveal a beautiful woman, Emmet suddenly gets is frozen on the spot by her beauty, the girl gets fed up and makes a run for it] Where are you going? Miss, I didn't mean to scare you! I'm so...aaahhh! as he starts going after her he trips and falls down a big hole in the ground] [as Emmet falls underground he gets continually knocked about] Hello! [he lands on his back in an area where half the walls are painted in rainbow colors] Hey, that's not so bad. [suddenly he starts to fall again and gets knocked about further until he finally falls to the ground and notices a giant block encased in crystal which is shining brightly] What is that?
[he hears a voice coming from the block]
Voice: Come here.
Emmet Brickowoski': What do I do? I don't have my instructions.
[the voice from the giant block gets louder]
Voice: Touch the piece.
Emmet Brickowoski: I feel like maybe I should touch that.
[Emmet gets up and starts walking over to the giant block, he becomes completely transfixed and steps over his instruction manual, he slowly extends his hand and touches the block and immediately gets a vision which includes Vitruvius reciting the Piece of Resistance prophecy]
Vitruvius (VO): A Special one with face of yellow, will make the Piece of Resistance found from its hiding refuge underground...
[Emmet then passes out]
[as Emmet slowly wakes he hears someone's voice interrogating him]
Bad Cop (VO): Wake up. Come on, wake up! Where is the Master Builder? Where did you find the Piece of Resistance? Hey?
[Emmet starts to open his eyes]
Emmet Brickowoski: Good morning apartment....?
Bad Cop: Wake up! [suddenly an angry looking cop shines a light onto Emmet making him immediately awake; he screams] Where did you find the Piece of Resistance?!
Emmet Brickowoski: The Piece of what?
Bad Cop: The Piece of Resistance.
[suddenly he knocks a chair aside in anger scaring Emmet, we see Emmet is being held in an interrogation room with his hands shackled to chair]
Emmet Brickowoski: I...I don't...! Where am I? What's happening?
[intercut to show an adjacent room with two robots watching monitors that display vital health information like heart rate etc. A screen to the left shows 'LIAR' which keeps blinking]
Bad Cop: (mocking) 'What's happening'? Playing dumb, Master Builder.
Emmet Brickowoski: No. I...'Master Builder'?
Bad Cop: (jumps onto the table and closes on Emmet) Oh, so you've never heard of the prophecy?
Emmet Brickowoski: No.
Bad Cop: Or the Special?
Emmet Brickowoski: No! No! I...
Bad Cop: You're a liar! We'll kill ya!
[Bad Cop starts to kick and wrestle around with the chair in the room]
[as Emmet watches Bad Cop continue to wrestle and kick the chair]
Emmet Brickowoski: Look, um...I watch a lot of cop shows on TV. Isn't there supposed to also be a...isn't there supposed to be a good cop?
[Bad Cop throws a chair in Emmet's direction and Emmet quickly ducks]
Bad Cop: Oh, yes. But we're not done yet.
[suddenly Bad Cop turns his face which changes to the cheerful Good Cop]
Good Cop: Hi, buddy! I'm your friendly neighborhood police officer. Would you like a glass of water? [he holds a cup of water toward Emmet]
Emmet Brickowoski: Yeah... Yeah, actually...
[Emmet goes to reach for the cup when suddenly Good Cop changes his face to Bad Cop]
Bad Cop: Too bad! [he then knocks cup off the table] Security cameras picked up this. [he shows Emmet the footage on the TV monitor next to them] You were found at the construction site convulsing with a strange piece.
Emmet Brickowoski: That's disgusting!
Bad Cop: Then why is it permanently stuck to your back?
[pull back to suddenly show the block attached to Emmet's back as he screams]
Emmet Brickowoski: [Emmet screams 'Aah! Aah!' and moves his chair back in an attempt to get the block off his back] Get off me! Get off me! It won't come off! It's chasing me! Look, it's not my fault! I have no idea how this thing got on my back!
[Good Cop suddenly appears]
Good Cop: Of course, buddy. I believe you.
Emmet Brickowoski: Great!
[suddenly Bad Cop appears beside Emmet with ''believe" in quotation marks]
Bad Cop: I 'believe" you too. You see the quotations I'm making with my claw hands? It means I DON'T believe you! [jumps onto Emmet] Why else would you show up with that thing on your back just three days before President Business is going to use the Kragle to end the world?
Emmet Brickowoski: President Business is gonna end the world? But he's such a good guy! And Octan... they make good stuff; music, dairy products, coffee, TV shows, surveillance systems, all history books, voting machines... Wait a minute.
[As Emet speaks the camera flashes past various scenes of music, dairy, coffee, TV shows etc] and then smash cuts back to the interrogation room]
Bad Cop: Come on, you can't be this stupid.
Emmet Brickowoski: Look, this is a misunderstanding. I'm just a regular, normal, ordinary guy.
[as he speaks we go to an Extreme Close Up of Bad Cop and his sunglasses]
Emmet Brickowoski (cont'd): And I'm late to meet my best friends in the whole world, and they're probably missing me right now. They're probably out looking around, "Hey, where's Emmet? Hey, where's my best friend Emmet?" And you know what? Ask all my friends, they'll tell you!
Bad Cop: Oh, we asked them alright. Boom!
[he turns on the TV monitor which shows Emmet's construction work colleagues being interviewed about Emmet]
Frank: That guy's not a criminal mastermind.
Emmet Brickowoski: See!
Jim: Yeah, he's kind of your average, normal, kind of guy.
Emmet Brickowoski: Thank you.
Jim: But you know, he's just... he's just like normal like us. yeah, he... he's just that special.
Gail: Wait I'm so confused. Who are we talking about?
[Emmet's smile starts to disappear; Gail looks at the photo of Emmet being shown to her]
Gail: Wait, does he work with us?
Emmet: Gail doesn't remember me?
Barry: Look at Randy here, he likes sausage. That's something. Gail is perky, that's something. Harry...well!
Frank: When you say Harry, I go... a=ha ha ha ha ha ha ha When you say the other guy, I go...
[he just looks into the camera showing no emotion, Emmet, now looking really upset, continues to watch his friends being interviewed]
Surfer Dave: I know that guy, but I know like zippy-zap about him.
Emmet: We just talked earlier.
Frank: And I mean, only does he is say yes to everything everybody else is doing.
[we see Larry the Barrista guy being interviewed]
Larry The Barrista: You know, I've got him like over the little bit of a...blank slate, I guess. [we hear him talking to a customer] That'll be forty-two $42 dollars, please.
Barry: We all have something that makes us something, and Emmet is...nothing.
[The videso stops. Emmet looks devastated; to Bad Cop]
Emmet: There you go. I told you I wasn't a nobody.
Bad Cop: No, it's the perfect cover.
Emmet Brickowoski: Cover? Cover for what?
Bad Cop: I can't break him. Take him to the melting chamber?
Emmet Brickowoski: What?
[in the melting chamber Emmet has been straps to the melting device]
Emmet Brickowoski: [screams] NO? NO? NO? NO? NO? NO? NO? NO? NO? NO? You're going to melt me? Am I gonna die??
Good Cop: You'll live, you'll be fine. (turns to Bad Cop)
[a phone rings and Bad Cop answers it]
Bad Cop: President Business. I have him right here, sir. Yes and no, we've told him he'll live so he doesn't matter try to escaping. But...we're lying to kill him.
[Bad Cop presses the button to activate the melting device and leaves]
Emmet Brickowoski: No wait, what did he just say?
Robot: Hold still.
Emmet Brickowoski: There's obviously been a mix up here! You've got the wrong... [a blue laser pointer is shoot at Emmet's back to removes the Piece of Resistance] Ow! Ow, ow, ow, ah-ah-ah-ah-eh-eh-eh-oh-oh-oh! This is gonna start hurting pretty soon!? [as the Robot starts to increase the power suddenly the hooded woman, Wyldstyle, that Emmett had noticed in the construction site earlier attacks the robots, takes them all down and goes to Free Emmet] No, no, no! [she frees him from his iron shackles] Whoa! Who are you? [she takes off her hood to reveal her face and Emmet is transfixed again] It's you?
[she extends her hand toward him]
Wyldstyle: Come with me if you wanna not die.
[just as Emmet goes to grab her hand Good Cop enters the chamber]
Good Cop: Hi, everybody! How is the melting going...?
[as he notices Emmet escaping with Wyldstyle Bad Cop appears]
Bad Cop: Hey, hey, hey? HEY. [he starts shooting at Emmet and Wyldstyle and laser pointer is destroys melting device] Red alert! Red alert! I need everyone, repeat, everyone, to go after the Special.
[after they escape from the melting chamber]
Wyldstyle: The tunnel's that way!
[as Emmet tries to follow her he lands on the ground with a garbage can stuck to his head]
Emmet Brickowoski: Oh, boy. [looking at Emmet with the garbage can on his head]
Wyldstyle: Oh, sir, you're brilliant! We'll build a motorcycle out of the alleyway. [she hops on top of the garbage can on his head and removes it]
Emmet Brickowoski: Oh! [then Wyldstyle starts gathering parts to build a motorcycle] So, uh...didn't catch your name or anything about what you're uh...up to, or what we're doing here.
Wyldstyle: It's brilliant, sir, that you pretended to be a useless nobody. But you can drop the act with me, it's cool.
Emmet Brickowoski: Oh, the act. [as Wyldstyle finishes building a really cool looking motorcycle] Woh!
Wyldstyle: Jump on. Let's go!
[Emmet jumps on to the back of the motorcycle and they leave]
Emmet Brickowoski: Hey, uh...
Wyldstyle: Hang on, sir.
[just then Bad Cop starts following them in his police car]
Bad Cop: All units, cut them off on Elm, NOW!
[suddenly his face changes to Good Cop]
Good Cop: Or whenever you can.
Robot: Yes, sir, Bad Cop.
[as they are being chased and shot at]
Emmet Brickowoski: Watch out!
Wyldstyle: Hold on! [Wyldstyle manages to avoid hitting the police cars in front of them] We need to meet up with Vitruvius and tell him the Piece has been found.
Emmet Brickowoski: Uh-huh.
Bad Cop: Caught up with them on a rail. Release the Copper Choppers.
[the helicopter above them drops down a motorcycle with two cops in it, they start shooting at Wyldstyle and Emmet but Wyldstyle shoots back and manages to get their motorcycle onto the street below]
Emmet Brickowoski: Will you please tell me what is happening?
Wyldstyle: I'm rescuing you, sir. You're the one that the prophecy spoke of, you're the Special.
Emmet Brickowoski: Me?
Wyldstyle: You found the Piece of Resistance and the prophecy states that you are the most important, most talented, most interesting and most extraordinary person in the universe. That's you, right?
Emmet Brickowoski: Uh...yes. That's me.
Wyldstyle: Great. You drive.
Emmet Brickowoski: What?!? [suddenly she jumps up to knock down the helicopter above them] [as Emmet is left to drive the motorcycle by himself, he's got no control over it and starts yelling] I wanna go home! This is not what I meant!
[as Wyldstyle is trying to take down one of the robot cops chasing them on a bike she sees Emmet swerving around on the road]
Wyldstyle: Oh, no! Look out, Special!
[to the other drivers on the road as Emmet tries to control the bike]
Emmet Brickowoski: I'm sorry! Never driven a motorcycle! I'm sorry!
'Wyldstyle: Wow, that's amazing! [Wyldstyle then manages to land onto their bike sitting behind Emmet] That was incredible! You're even better than the prophecy said you'd be.
Emmet Brickowoski: Oh, really?
Wyldstyle: I'm uh...I'm Wyldstyle.
[as he tries to avoid hitting another vehicle]
Emmet Brickowoski: Oh, I'm sorry. What was that?
Wyldstyle: Wyldstyle.
Emmet Brickowoski: Wyldstyle?
Wyldstyle: Yep.
Emmet Brickowoski: What are you, a DJ?
Wyldstyle: No.
Emmet Brickowoski: Oh, that's your name? It's Wyldstyle?
Wyldstyle: Yeah.
Emmet Brickowoski: Like on your birth certificate it says Wyldstyle?
Wyldstyle: Let's not talk about my name!
[instructing his robot cops as he chases after Emmet and Wyldstyle]
Bad Cop: Don't let the special get away!
Robot: No, we blocked the freeway-
Wyldstyle: [to Emmet] Hang on, sir.
Emmet Brickowoski: What are you doing?
[suddenly Wyldstyle starts assembling their vehicle into an aircraft]
Wyldstyle: Let's fly! Let's head to the secret tunnel.
[as they get close to the city walls]
Emmet Brickowoski: Uh...these are the city limits!
Wyldstyle: Let's just head for the tunnel.
[as they get nearer to the wall it suddenly opens up to reveal a secret tunnel]
Emmet Brickowoski: You want me to drive into that weird swirly hole?? Are you insane???
Wyldstyle: Don't break? Go? Don't stop? Go, now?
Emmet: I can't do this? [suddenly Emmet goes to jump out but Wyldstyle grabs him and pulls him back] That is against the instructions???
Wyldstyle: Wait. What's your favorite restaurant?
Emmet: Any chain restaurant.
Wyldstyle: Favorite TV show?
Emmet: "Where are my pants."
Wyldstyle: Favorite song?
Emmet: "Everything is Awesome!"
Wyldstyle: Oh, no?
[at that moment they enter the secret tunnel in the wall and it immediately closes up after them making the police cars chasing them and the helicopter crash into it]
Bad Cop: Darn, darn, darn, darny-darn!
[he starts kicking a metal object in anger, one of the cops behind him starts running off, Bad Cop kicks the metal object and it lands on top of the cop that was
running off]
Bad Uop: Gig
[Emmet and Wyldstyle enter into a new Lego world, Emmet screams as he falls and finally lands onto the ground, Wyldstyle leaves him screaming]
Emmet Brickowoski: Wait. Where are we? [a sign comes up to announced this new Lego world as "The Old West"] This is so weir-- [suddenly Wyldstyle walks over to him and hits him with a giant cactus] Ow!
Wyldstyle: You're not the Special! You lied to me!
Emmet Brickowoski: Well, I mean it depends...it really depends on...
Wyldstyle: You're not even a Master Builder, are you?
[Wyldstyle turns and starts walking off and Emmet follows her]
Emmet Brickowoski: Uh...I mean I know what a Master Builder is, why don't you tell me what it is? That way I could see if you're right.
Wyldstyle: You ruined the prophecy.
Emmet Brickowoski: I'm sorry, okay? You just made being Special sound so good.
Wyldstyle: To think I was going to follow you to the end of the universe.
Emmet Brickowoski: You were? Well, here's the thing, how do we know for sure that I'm not the Special? We just don't know it yet.
[just then Wyldstyle pulls Emmet behind a gravestone as she hears people in the distance]
Wyldstyle: Quiet!
[Wyldstyle and Emmet watch two cowboys in the distance]
Cowboy #1: You all wanna dry turkey leg?
Cowboy #2: Do you have any idea what that does to your colon?
[suddenly Wyldstyle slips in from above, attacks them and knocks them out]
Emmet Brickowoski: Oh, my G-O-S-H.
[Wyldstyle throws Emmet a cowboy hat]
Wyldstyle: Just put the hat on. Oh, and this. And this, and this. And this. [from inside the cowboys wagon she throws him a poncho, gun and a horse] And by the way, I have a boyfriend.
[she turns and we see she's wearing an old fashioned western dress]
Emmet Brickowoski: I'm not sure exactly why you bring that up.
Wyldstyle: Super serious and you do not want to mess with him.
Emmet Brickowoski: Okay.
Wyldstyle: So, don't get any ideas.
[she jumps onto one of the cowboy's horse]
Emmet Brickowoski: I never have any ideas. [Emmet sits his horse up and it suddenly runs off] Wait! [after catching his horse, Emmet catches up with Wyldstyle and rides beside her] Hey, uh...listen. Do you think you can explain to me like why I'm dressed like this and what those big words in the sky were all about and like where we are in time?
[she huffs at him in frustration and her horse does the same]
Wyldstyle: Your home, Bricksburg, is one of many realms in the universe. There's also this one, Pirates Cove, Knights Club, Vikings Landing, Clown Town, a bunch of others we don't need to mention.
[as she speaks the camera smash cuts past various other worlds according to what she says. Slam cut back to Emet and her]
Emmet Brickowoski: Mm-hmm.
Wyldstyle: Lord Business, or as you think you know him, President Business, stole the Kragle, the most powerful object in the universe--- [as Emmet listen to her he starts seeing and hearing her in a slow dream voice] Blah, blah, blah. Proper name. Place name. Backstory stuff...
Emmet Brickowoski: Mm-hmm.
Wyldstyle: ...is the Special. The Special... [again as he watches her he hears her voice in a slow dreamy voice] I'm so pretty. I like you. But I'm angry with you for some reason.
Emmet Brickowoski: Mm-hmm.
Wyldstyle: ...at the end of the universe, put the Piece of Resistance onto the Kragle and disarm it forever!
Emmet Brickowoski: Great. I think I got it. But just in case, tell me the whole thing again, I wasn't listening.
[Wyldstyle huffs at him in frustration again as does her horse]
Wyldstyle: Okay, all the people of the universe were once free to travel and mingle and build whatever they wanted. But President Business was confused by all the chaos, so he erected walls between the worlds and became obsessed with order and perfection, and he stole the mysterious secret super weapon called...
[flashback to when Lord Business stole the Kragle from Vitruvius]
Lord Business: The Kragle!
Wyldstyle: And he hired Bad Cop to hunt down all the Master Builders, who were always changing everything. Those of us who remained, well we went into hiding, built tunnels to survive. And we searched for the Piece of Resistance, the only thing that can stop the Kragle.
Emmet Brickowoski: The Kragle, I know that. I mean, that cop, well he said something about the Kragle, President Business was going to use the Kragle to end the world in three days. I can't make any sense of it.
[suddenly Wyldstyle realizes something]
Wyldstyle: Taco Tuesday! I knew that was suspicious. There's no time to lose! We must find Vitruvius and get to the Office Tower before it's too late!
[she starts rushing off]
Emmet Brickowoski: Okay. How scary can someone's office be?
[at President Business' Office which is located at the very top of Octan office tower, Emmet's face is plastered on all the monitors as the robots try to find him]
Robot #1: President Business, we're trying to locate the fugitive, but his face is so generic, it matches every other face in our database!
President Business: Diabolical. Okay, have Bad Cop meet me in my office in...twenty three seconds.
Robot #1: Will do, sir.
President Business: Ciao!
Robot #2: Coffee sales are up, sir.
President Business: Glad to hear it. Let's rebuild that roof to be even higher.
Robot #3: Roof building, we're on it!
Robot #4: Sir, can you approve this poster for Taco Tuesday?
President Business: Perfect. Wooh! I love everyone on this room.
Robots: We love you, sir!
[going through to the radio station where the song "Everything is Awesome" is being played]
President Business: Hey, guys. Great job on the radio station.
Robot DJ's: Thank you, sir. We love listening to this song over and over again.
President Business: Keep it up, guys.
[in the TV station we see the actors for the show "Where Are My Pants?"]
Actor on TV Show: Honey? Where are my pants?
[the audience laughs]
Director: And cut!
[going over to the actors]
President Business: Hilarious. That never gets old.
Actor on TV Show: Oh, it does not.
Velma Staplebot: Bad Cop is waiting for you in your office.
President Business: Wonderful, fantastic. Would you cancel my two o'clock, this next meeting could run a little bit...DEADLY.
[President Business changes into his Lord Business outfit with his giant iron legs]
Octan Computer: Activate helmet. Light sequence. Flame test. Engage dramatic entrance.
[suddenly Lord Business enters his office is a cloud of smoke killing two assistants as he did in the intro with Vitrivius]
Lord Business: Bad Cop!
[Bad Cop backs away in fear as Lord Business approaches him]
Bad Cop: Lord Business, I know the Special got away. But...
Lord Business: Don't be so serious. Where's the other guy?
[Bad Cop face turns to Good Cop]
Good Cop: Hey, hey!
[he starts waving in a cheerful manner and bobs his head before bowing]
Lord Business: Hey, buddy. I missed you.
Good Cop: Oh, did you really?
Lord Business: Have I ever shown you my relic collection?
Good Cop: Nope, I don't think you have.
Lord Business: Nobody knows where this stuff comes from. [he shows Good Cop a giant band-aid] This one is the cloak of band-aid. I hear it's super painful to take off. You wanna try it on?
Good Cop: Well, uh...
[suddenly Bad Cop appears]
Bad Cop: No, but thank you.
[Business throws the plaster aside and it hits an assistant on the side, stuck to the man. He falls and a second assistant tries to help him]
Lord Business: We've done some great work over the years together, Bad Cop. Capturing all those Master Builders and torturing them and what not.
[in the background both assistants sway and fall having been stuck to the plaster]
Bad Cop: Thank you, sir.
Lord Business: Although, you did let the Piece of Resistance go. The one thing that can ruin my plans, the one thing that I asked you to take care of. [he comes over to Bad Cop and puts one arm around his shoulder] That's super frustrating, y' know? It makes me just wanna pick up whoever's standing closest to me and just Throw them through this window, and out into the Infinite abyss of nothingness!
[camera pans down to show the abyss going to a different world then returns to the two]
Lord Business (cont'd): [he picks up Bad Cop takes him to the large glass window and bangs his head against it] I wanna do it so bad.
Bad Cop: I know you do, sir. But please, please don't.
[Business throws Bad Cop to the back]
Lord Business (cont'd): And it's not just you, Bad Cop, that keeps messing up my plans. People everywhere are always messing with my stuff. But I have a way to fix that. A way to keep things exactly the way they are supposed to be...permanently.
[he turns on his TV monitor which shows his robots carrying the box containing the Kragle]
Lord Business: Behold: the most powerful weapon of all the relics: [his robots open the box containing the Kragle and take it out] THE KRAGLE! [we see the Kragle is in fact an old tube of Krazy Glue] As you can see they're loading the Kragle into a big machine upstairs. I call it "The Tentacle Arm Kragle Outside Sprayer", or Takos! The S is silent. So on Taco Tuesday it's going to spray the Kragle over everyone and everything with a bunch of super scary nozzles, like this one. [the tentacle reaches out and comes over to Bad Cop who bends backwards trying to avoid it] I'll show you how it works.
Bad Cop: Sir, I don't know if this is necessary.
Lord Business: Oh, don't worry. I won't test it on you. I'll do it on your parents!
[Bad Cop's parents spring up from underground]
Pa Cop: Hiya, son.
Ma Cop: Hi!
Pa Cop: How's it going in the big city?
Bad Cop: Mommy, Daddy, what are you doing here?
Lord Business: Okay, Pa, I just want you to act naturally. Like you're...you're going about your day.
Pa Cop: Got you.
Lord Business: Yeah, keep your hand up like that. Ma, scoot two steps into the right.
[as Ma Cop goes to move Pa Cop starts to turn]
Lord Business: Pa?
Pa Cop: Uh-huh.
Lord Business: Why do whenever I talk to Ma you start to move?
Pa Cop: I'm sorry.
Lord Business: Get back to where you were!
[Pa Cop moves to stand next to Ma Cop]
Pa Cop: Here?
Lord Business: Perfect. That's great! You can't do anything better, there's no reason why you should move.
Pa Cop: Right.
Lord Business: Now, Ma, hand on his shoulder. And you... [as Ma Cop goes to place her hand on Pa Cop's shoulder he turns] Pa, you just moved and just wrecked it!
Pa Cop: Uh-huh.
Lord Business: YOU WRECKED IT! Bad Cop, you see what I'm talking about? All I'm asking for is total perfection. Send in a micro-manager! [a giant robot comes up from underground and puts Pa and Ma cop in place]
Robot: Commencing micro-management.
Lord Business: Hold still, guys. [the TAKOS device comes over to them] Then I just spray them with the Takos!
[the Krazy Glue is sprayed onto the Pa and Ma cop]
[as they are being sprayed with Krazy Glue]
Ma Cop: Oh, Pa. Hold me!
Pa Cop: Oh, darlin', I can't move me legs.
[Bad Cop watches them looking visibly upset]
Lord Business: Does that upset you, Bad Cop?
Bad Cop: Um...
Lord Business: Surely you feel bad for you parents and you want to help them, don't you?
Pa Cop: We're okay son. Just a little stuck is all.
Lord Business: Go ahead, finish the job.
Bad Cop: Of course, sir.
[his face suddenly changes to Good Cop]
Good Cop: No, I don't want to!
[he then keeps changing back and forth between Bad Cop/Good Cop]
Bad Cop: You have to!
Good Cop: I don't want to!
Bad Cop: Would you please be quiet?!
Good Cop: I can't!
Bad Cop: You must.
Good Cop: But they...
Bad Cop: Shut it!
Good Cop: It's not nice.
Bad Cop: It's your job, man!?
[he finally turns back to Good Cop and gives up]
Good Cop: I can't do it! [turning to Lord Business] They're innocent!
Lord Business: Just as I thought. Your Good Cop side's making you soft, Bad Cop. (we see Good Cop staring at the camera with his eyes watering) Robots, bring me the Fleece Crested Scepter of Q-tip and Polish Remover of Nail. [the robots bring him the items and Lord Business deeps one end into the polish before turning to Bad Cop, meanwhile Good Cop becomes Bad Cop in an attempt to protect his good side] You've already let the Special get away once. [two of the robots hold Bad Cop]
Bad Cop: Sir... Wait!
Lord Business: I'm just gonna make sure it doesn't happen again. [one of the robots turns Bad Cop's face to Good Cop] NO MORE MR. NICE GUY!!!
[suddenly Lord Business uses the end of the Q-tip with nail polish remover to wipe Good Cop's face off, Ma Cop starts to weeps]
Ma Cop: Oh, son!
Pa Cop: [shocked] Son, no!
Lord Business: On Taco Tuesday I'm going to Kragalize the entire universe so that [tries to kill Bad Cop] everyone will stop messing with my stuff??? [he turns to Good Cop] Are you gonna be with me or are you gonna be stuck having a tea party with your Mom and Dad??
[Good Cop, who's face is now blank, doesn't respond]
Pa Cop: Son?
[suddenly Good Cop's blank face changes to Bad Cop]
Bad Cop: Sorry, Dad. I have a job to do.
[he uses the TAKOS device to completely glue his parents]
[back to Emmet and Wyldstyle, who are dressed in their disguise about to enter into a saloon]
Wyldstyle: All you have to do is blend in and act like you belong here.
Emmet Brickowoski: Oh, perfect. [Emmet enters and starts jumping around doing a really bad cowboy accent] Well, hi there
I'm a cowboy! Bang-bang, bang-bang-bang! Shoot, shoot, shoot! Bullet, bullet, gun! Zap, zap, zap! Pow, zap, pow! [suddenly the whole saloon goes quiet and turns to look at him, at that point Wyldstyle quickly enters and moves Emmet outside] What are they looking at?
Wyldstyle: I-I-I made a mistake. You should just be still, act like a stool.
[Emmet bursts into the saloon again]
Emmet Brickowoski: Howdy, guys!
[Emmet bends down trying to act like a stool]
Wyldstyle: No, stools don't talk.
Emmet Brickowoski: Come sit on me!
Wyldstyle: Stools don't talk. [Wyldstyle picks Emmet up again and moves him outside] Okay, ssh. Let me show you how it's done.
[Wyldstyle enters with holding her fan up to her face, she then spits into the spittoon]
Cowboy in Saloon: What a lady!
[everyone in the saloon starts to go about their business again]
[to Emmet as they make their way through the saloon]
Wyldstyle: Okay, let's find the wizard and get this over with. [Wyldstyle notices Vitruvius playing the piano at the saloon] There he is. [she goes over to him] Vitruvius.
Vitruvius: Who? I've never heard of that man, whom I am not. Who are you?
Wyldstyle: It's me.
Vitruvius: I am a blind man, I cannot see.
Wyldstyle: It's Wyldstyle.
Vitruvius: Are you a DJ?
Wyldstyle: What? Why is everybody...?
Vitruvius: Oh! Wait, wait. Are you the student I used to have who was so insecure she kept changing her name?
Wyldstyle: No! No, no.
Vitruvius: Yeah, first Dark Storm...
Wyldstyle: Ssh. No.
Vitruvius: Then Gemini, then there was Neversmile---
Wyldstyle: Whatever.
Vitruvius: Then Freak Face...
Wyldstyle: Ssh-sh. Okay. Okay.
Vitruvius: Then Snazzypants...
Wyldstyle: Alright! Yes! [suddenly Vitruvius stops playing and turns to Wyldstyle]
Vitruvius: Meet me upstairs in ten seconds, he then turns and starts to walk off using his [scepter when suddenly he bangs into the wall and falls]
[10 seconds later; they meet upstairs and enter into a room full of stuff collected from all the different Lego worlds]
Emmet Brickowoski: Oh, man. You have a very weirdly decorated place.
Vitruvius: Thank you.
Wyldstyle: Vitruvius, we have found the Piece of Resistance.
Vitruvius: Is it true?
Wyldstyle: Yes, but...
Vitruvius: Wyldstyle, the prophecy states that you are the Special. The embodiment of good, foiler of evil, the most talented, most brilliant, most important person in the universe.
Wyldstyle: That would be great, but...Emmet is the one who found the Piece.
[Emmet turns and waves]
Vitruvius: Oh, okay. [turning to Emmet] Emmet! The prophecy states that you are the Special. The most talented...
Wyldstyle: I'm not sure he's the Special, actually, because he's not even a Master Builder. Watch. Emmet, just given what's around you, build something simple.
Emmet Brickowoski: Okay.
Wyldstyle: Like an awesome race car.
Emmet Brickowoski: Great.
Wyldstyle: Go.
Emmet Brickowoski: Do you have the instructions?
Vitruvius: No. You must create the instructions in your mind, my liege.
Emmet Brickowoski: Ha. Okay. Race car. [he starts looking around the room] Um...well, there's a lot of really cool stuff here. I don't see a wheel or...three more wheels.
Wyldstyle: [to Vitruvius] See! He can't do it. He will never be a Master Builder.
Vitruvius: Of course not, not if you keep telling him he can't. He needs to see that he can.
[Vitruvius goes over to Emmet and puts his hands against Emmet's head]
Emmet Brickowoski: What are you doing? [suddenly Vitruvius pops off Emmet's hair revealing his Lego head]
Vitruvius: We are entering your mind...
Emmet Brickowoski: What?!
Vitruvius: To prove that you have to unlock the potential to be a Master Builder.
[Vitruvius and Wyldstyle start bowing and moving around Emmet until finally we see all of them in Emmet's mind which is a vast empty space]
Emmet Brickowoski: Woah! Are we inside my brain right now? It's big. I must be smart.
Wyldstyle: Mm-hmm.
Vitruvius: I'm not hearing a lot of activity here.
Wyldstyle: I don't think he's ever had an original thought in his life.
[Emmet laughs]
Emmet Brickowoski: That's not true. For instance, one time I wanted to have a bunch of my friends over to watch TV. [suddenly a TV forms behind him] Not unlike this TV that just showed up magically. And not everybody could fit on my one couch. [a couch forms behind him] And I thought to myself, "well, what if there was such a thing as a bunk bed, but as a coach?" [suddenly the couch forms into a double decker couch] Introducing the double decker coach. So everyone can watch TV together and be buddies.
[there's a moment's silence]
Wyldstyle: That is literally the dumbest thing I've ever heard.
Vitruvius: Please, Wyldstyle. Let me handle this. [to Emmet] That idea is just the worst. [as they float around Emmet's empty mind] There must be something around here that proves his potential. If The Man Upstairs chose him to the Special, there must be a reason.
Emmet Brickowoski: Who's The Man Upstairs?
Wyldstyle: See? He doesn't even know about The Man Upstairs.
Emmet Brickowoski: Does he have super gross hands that look like they're made out of big pink sausages, like eagle talons mixed with squid?
[suddenly they turn to see Emmet being raised up on a large human-like hand]
Wyldstyle: Wait. You've seen the...?
[Emmet turns and notices he's standing on a large hand]
Emmet Brickowoski: Wow! That's what I was just thinking about!
Wyldstyle: How did you...?
Emmet Brickowoski: I had this weird dream when I touched the Piece. Well, I...I mean I wasn't asleep, so it wasn't really dream...
Vitruvius: Emmet, you had a vision.
Emmet Brickowoski: I did?
Vitruvius: Master Builders spend years training themselves to clear their minds enough to have even a fleeting glimpse of The Man Upstairs. And yet, your mind is already so prodigiously empty that there is nothing in it to clear away in the first place. With proper training you could become a great Master Builder.
Emmet Brickowoski: I could?
Vitruvius: The prophecy chose you, Emmet.
Emmet Brickowoski: But I can't do any of the stuff that the prophecy says I'm supposed to do.
Vitruvius: All you have to do is to believe, then you will see everything. Are you ready, my son?
Emmet Brickowoski: Yes, I am. I think.
Vitruvius: Then we haven't a moment to lose. We must assemble the Master Builders.
[back in the saloon one cowboy points his gun at another cowboy]
Cowboy: Do you think zeppelins are a bad investment?
[suddenly Bad Cop enters the saloon on a horse]
Bad Cop: Have any of you fellas seen this guy?
[he holds up a hand drawn picture of Emmett, the town Sheriff speaks up]
Sheriff: Wait a minute, partner. Draw a cowboy hat on him.
[Bad Cop draws a cowboy hat on Emmet's picture and show it to him and the sheriff recognizes him; back in Vitruvius's room]
Vitruvius: These mechanical birds will get our message out. They will go to an internet cafe and email the remaining Master Builders who will meet us in the secret realm of Cloud Cuckoo Land.
[he throws the birds out of the window]
Emmet Brickowoski: Cuckoo Land? Wait, what happened to that whole training part?
Vitruvius: Don't worry, Emmet. Your training begins now.
[suddenly they hear a knock on the door]
Sheriff: Piano Man, open up!
Vitruvius: Your training begins later!
[as Vitruvius, Emmet and Wyldstyle try to make their escape the Sheriff's men throw a dynamite at the door]
Sheriff: On three. One...
[the deputy presses the fuse and the door blows open, they enter the room and we see Vitruvius, Emmet and Wyldstyle have escaped up through a hatch on the roof]
[as they escape through the roof hatch]
Wyldstyle: I think we're in the clear.
Bad Cop: Freeze, turkeys! [they look down to see Bad Cop and his army of robots all assembled outside the saloon] All I want is the Piece of Resistance.
Wyldstyle: We would rather he died than give it to you!
Emmet Brickowoski: I...would not rather he died.
Bad Cop: Look everybody we can do this the easy way or we can do it...
Wyldstyle: Go, run!
Bad Cop: They took the hard way. Fire! Fire!
[his army of robots start firing at the trio as they continue to run and jump off the roof tops]
Wyldstyle: Vitruvius! Which way to Cloud Cuckoo Land?
Vitruvius: Head for the big bright thing in the sky.
Emmet Brickowoski: Do you mean the sun?
Vitruvius: Yeah, yeah. That's it.
Wyldstyle: Let's get out of here. Here use this.
[Wyldstyle quickly builds a vehicle]
Emmet Brickowoski: What? Wait, what are you doing?
Wyldstyle: Let's go!
[they fly off on Wyldstyle's vehicle as the robots continue to shoot at them]
Emmet Brickowoski: I don't know what I'm doing. Aaahh!
Bad Cop: Goodbye. [Bad Cop aims and shoots his gun] Boom!
[the trio's vehicle explodes into pieces and the trio land in a water tank]
[as the trio fall to the ground Emmet and Vitruvius end up in a pig pen]
Emmet Brickowoski: Ah! I got pigs! I hate pigs!
Wyldstyle: Guy's quite playing around in the mud, I could use your help.
[Emmet and Vitruvius follow Wyldstyle with the pigs chasing after them]
Emmet Brickowoski: Wyldstyle, we could really use your help!
[as they nearly run into a robot Wyldstyle manages to build another vehicle which uses the pigs to get them away in time]
Wyldstyle: Vitruvius, they're gaining on us! Build something!
Vitruvius: Let Emmet try!
Emmet Brickowoski: No, let's not let Emmet try! I haven't had any training!
Vitruvius: That's okay, we'll start with how to become a Master Builder. Step one; trust your instincts.
[Emmet picks up a Lego piece not sure what to do]
Emmet Brickowoski: Okay. Okay. Um...
Wyldstyle: Build something! Building something!
Emmet Brickowoski: Ah-ha! Take that! [he throws the Lego piece at the robots which is immediately run over by the army of robots chasing after them]
Vitruvius: Unless your instincts are terrible. [just then the sheriff starts shooting at them and suddenly a wheel comes off their vehicle as they're heading towards the edge of a cliff] No, the wheel!
[their vehicle goes out of control as they head towards the edge of a cliff]
Wyldstyle: I can't control it any longer!
Vitruvius: Emmet, we need to attach the wheel to something that spins around.
Emmet Brickowoski: Um...
Vitruvius: We need to attach the wheel to something that spins around. [Emmet head starts spinning as Vitruvius's voice keeps echoing in his head] We need to attach the wheel to something that spins around. We need to attach the wheel to something that spins around...something that spins around....spins around... spins around...
[suddenly Emmet gets an idea, he pops off his hair and attaches the wheel to the top of his head and makes his way down the side of the vehicle]
Wyldstyle: Emmet, where are you going? [Emmet positions where the wheel would go which should help Wyldstyle steer the vehicle] Oh, this better work!
[just as they reach the edge of the cliff Wyldstyle manages to turn and avoid going down, but the robots go over the edge and explode as they hit the ground]
Vitruvius: Well done, Emmet!
Emmet Brickowoski: Hey, I did it!
Wyldstyle: Wow, you actually did it. [suddenly they hear they a train coming as an engine blows its whistle, hauling its coal tender, and lots of heavy freight cars] TRAIN!
[their vehicle crashes into the train cars, making the trio jump up into the air, which makes Emmet get his hair attached back and then they all land on top of the freight cars of the train]
Wyldstyle: Oh, no!
Bad Cop: Get off my train?
Wyldstyle: Run!?
[the trio start running across the train toward the engine as Bad Cop chases after them, as Bad Cop aims to shoot at them Emmet jumps in front of Wyldstyle to save her]
Emmet Brickowoski: Wyldstyle!
[Emmet gets hit and starts to cry]
Wyldstyle: He's gonna ram us. Quick, quick, quick! Give me that piece! Build a ramp!
Bad Cop: [as Bad Cop heads toward them with his car he crashes into the ramp and falls off the train but manages to avoid crashing to the ground as his vehicle transforms into a flying vehicle and he heads back up] Huh?
Wyldstyle: What the heck?!
Bad Cop: Rest in pieces.
[Bad Cop shoots at the bridge making it explode]
Wyldstyle: Oh, no.
[the train derails and starts falling down as the engine, its coal tender, and several freight cars plummet into the river]
Emmet Brickowoski: What are we gonna do?
[as they plummet toward a chasm with crocodiles below everything becomes slow motion and Wyldstyle looks at Emmet]
Wyldstyle: Hey, thanks for saving my life back there. Even if, you know, eventually it turned out to be pointless.
Emmet Brickowoski: Well, for what it's worth, this has been about the greatest fifteen minutes of my life.
[as they go to hold hands they are suddenly saved by Batman flying in with his aircraft]
Bad Cop: What the...?
[after Batman flies in and saves them]
Batman: Relax, everybody, I'm here.
Emmet Brickowoski: (jumps up and down, Vitrivius blinks) Batman!
Batman: [to Wyldstyle] What's up, babe?
Wyldstyle: Batman
Emmet Brickowoski: What?
Wyldstyle: Oh, sorry. Batman, this is Emmet. Emmet, this is my boyfriend. Batman.
Batman: I'm Batman.
Emmet Brickowoski: That's your boyfriend? [Batman swerves his aircraft to avoid getting hit by Bad Cop as he chases after them] Batman, huh? Where did you guys meet?
Wyldstyle: It's actually a funny story. Right, Bat...?
[she turns to see Batman has disappeared]
Bad Cop: There he is!
Batman: "Police" to meet you, Bad Cop.
[Bad Cop sees Batman has landed on his vehicle]
Bad Cop: Batman! The pleasure is all "spine"!
[Bad Cop punches Batman, then they start fighting on top of Bad Cop's vehicle]
Batman: Guess what, you big dumb baby? Your car is a baby carriage.
[Batman transforms Bad Cop's vehicle into a baby carriage and it start plummeting to the ground, Bad Cop and Batman both scream]
[as they watch Bad Cop plummet with Batman on his vehicle]
Emmet Brickowoski: Oh, no. Your boyfriend's gone.
Batman: Hey, babe.
[they turn to see Batman sat back in the drivers seat]
Emmet Brickowoski: What?!
Batman: [to Wyldstyle] Let's hold hands.
[Batman and Wyldstyle hold hands, Emmet watches them hold onto each other]
Emmet Brickowoski: So, uh... Hey, guys? I think we're about to crash into the sun...
Batman: Yeah, but it's gonna look really cool.
[as they crash through the sun, Batman's vehicle leaves a Batsignal in the middle of the sun]
[after crashing through the sun they end up in another Lego world]
Emmet Brickowoski: Uh...is this Cloud Cuckoo Land? I don't see any clouds, or cuckoos.
Vitruvius: No, no. This is Middle Zealand. [camera smash cuts various scenes as he speaks] A wondrous land full of knights, castles, muttons, torture weapons, poverty, leaches, illiteracy, and um...
[suddenly a dragon flies towards them]
Emmet Brickowoski: DRAGONS!!!
Vitruvius: Yeah, that too. [Batman makes his aircraft transform into a car and lands on the ground and drives through the woods] Once we arrive in Cloud Cuckoo Land, we'll raise an army of Master Builders...
Batman: Yeah, yeah, anyway. You guys gotta check out these new subwoofers I installed in the back, I call them "The Dogs." Listen to 'em bark!
[he turns on his stereo making Emmet and Vitruvius jump in the back]
Emmet Brickowoski: Aaah! Can you turn that down a little bit!
Batman: This is a song I wrote for Wyldstyle! [we hear Batman's voice as he sings to the heavy metal music] Darkness. [to Emmet and Vitruvius] It's about how I'm an orphan. [the song continues] No parents.
[Wyldstyle turns to Emmet]
Wyldstyle: This is real music, Emmet. Batman's a true artist. Dark, brooding.
Emmet Brickowoski: Well, I'm dark and brooding too! [suddenly he notices something ahead] Oh, guys! Look, a rainbow!
[as they reach the rainbow]
Vitruvius: So, you're gonna drive up the curved part, take it all the way to the top and park the car. [Batman drives up the rainbow and stops the car at the very top] Friends, welcome to Cloud Cuckoo Land. [the rainbow disappears and they are surrounded by clouds] Now, I just need to give the secret knock.
[he turns and knocks once with his scepter on the cloud door, after a short pause the door bursts open and as they enter inside they hear music being played and everyone is happy and dancing around]
Emmet Brickowoski: Okay. I'm just gonna come right out, I have no idea what's going on or what this place is, at all.
[suddenly a cat comes up to them]
Unikitty: Hi! I am Princess Unikitty, and I welcome you all to Cloud Cuckoo Land!
[Unikitty guides them through her happy whimsical the city]
Emmet Brickowoski: But there's no signs or anything! How does anyone know what not to do?
Unikitty: Here in Cloud Cuckoo Land there are no rules! There's no government, no babysitters, no bed times, no frowny faces, no bushy mustaches, and no negativity of any kind.
Wyldstyle: You just said the word no like a thousand times.
Unikitty: And there's also no consistency.
[as a clown and crocodile dance around him]
Batman: (to himself) I HATE this place.
Unikitty: Any idea is a good idea, except the not happy ones. Those we push down deep inside where you never, ever, ever, EVER... [her happy face suddenly changes to a deep angry face for a second before turning back] ...find them! [to Emmet] Your fellow Master Builders are gathered in The Dog.
Emmet Brickowoski: The...what? [the four go to a giant dog head where all the other Master Builders are gathered] Is that Superman?
Statue of Liberty: Oh, Superman.
Superman: Girl, what are you doing right now?
Green Lantern: Hey, Superman!
Superman: Oh, he... Hey, what's up?
Green Lantern: Lantern. Green Lantern.
Superman: Yeah, yeah.
Green Lantern: You wanna sit together at the meeting?
Superman: Um...I have to...I have to go back to Krypton.
[Superman quickly flies off]
Green Lantern: Did...didn't Krypton blow up?
[addressing the Master Builders]
Vitruvius: My fellow, Master Builders, including, but not limited to: Robin Hood, Mermaid Lady, Gandalf, Swamp Creature, 1980-something Space Guy...
Benny: Hello!
Vitruvius: 2002 NBA All Stars and Wonder Woman. You have traveled far to be here for a moment of great import. We have learned that Lord Business plans to unleash a fully-weaponized Kragle on Taco Tuesday, to end the world as we know it. [the Master Builders express their shock and outrage] Please, calm yourselves. Green Ninja, Milhouse, Nice Vampire, [the vampire turns into a bat] Michelangelo, Michael Angelo and Cleopatra. There is yet one hope, the Special has arisen. [he points to Emmet who looks terrified]
Gandalf: Have the young man step forward
Vitruvius: As you wish, Dubbledore.
Gandalf: I'm Gandalf!
Dumbledore: It's pronounced Dumbledore.
Vitruvius: Dubbledore?
Dumbledore: No! DUMBLEDORE!
Vitruvius: I thought you said Dubbledore.
Gandalf: VITRIVIUS!!!
Vitruvius: Ah, you gotta write all that down cause I'm not gonna remember any of it, but here we go. The Special will now give an eloquent speech. [everyone stares at Emmet who looks around the room in an awkward silence] Go ahead, man. You've got this.
Emmet Brickowoski: Okay. [Emmet walks up to the platform and waves to everyone] Hello. I'm Emmet. [referring to the block stuck to his back] Oh, and this is the Piece of Resistance. [the Master Builders express their excitement] Thank you. Well, uh...I know that I for one am very excited to work with you guys. To get into the Octan Tower, find the Kragle and put this thing on the thing! And I know it's going to be really hard, but...
[suddenly he's interrupted by a large Master Builder known as Metal Beard]
Metal Beard: Really hard?! Wiping ye bum with a hook for a hand is ''really hard". This be impossible! The last time we tried to storm Lord Business's office we used every plan we could conceive, the result was a massacre too terrible to speak of.
Emmet Brickowoski: Who are you?
Metal Beard: The name be Metal Beard! And I'll tell you me tale of woe.
Vitruvius: Oh, great. Here we go again.
[Metal Beard recounts his failed attempt in trying to infiltrate Lord Business's office]
Metal Beard:[camera switches as he speaks to show him and his crew] I arrived at the foot of the tower with me hearty Master Builder crew, only to find the Kragle was all the way up on the infinitieth floor guarded by a robot army.
[camera smash cuts to show the security measures as he goes on]
Metal Beard: And security measures of every kind imaginable; lasers, sharks, laser sharks, overbearing assistants, and strange dangerous relics that entrap, snap and zap. [an explosion rocks the tower and he barely escapes] And there be a mysterious room called "The Think Tank."
Metal Beard: I barely made it out of that room with just me head!... And organs.
Emmet Brickowoski: Okay.
Metal Beard: I had to replace every part of my once strapping virile pirate body with this useless hunk of garbage ye see before ye. [to Emmet] So if ye think it'd be a good idea to return to that foresaken place, Special, what idea have ye that be better than the ideas of one hundred of our fallen Master Builder brothers?
Emmet Brickowoski: Well...well, technically I'm not exactly a Master Builder yet...
Metal Beard: What?!
[there's shocked outrage from the other Master Builders]
Emmet Brickowoski: Please, everyone. Everyone! Please!
William Shakespeare: Rubbish!
Emmet Brickowoski: [addressing the Master Builders] Yes, it's true. I may not be a Master Builder. I may not have a lot of experience fighting or leading or coming up with plans, or having ideas in general. In fact, I'm not all that smart. And I'm not what you'd call a creative type. Plus, generally unskilled. Also, scared and cowardly. I know what you're thinking, "he is the least qualified person in the world to lead us." And you are right.
Swamp Creature: This is supposed to make us feel better?
Emmet Brickowoski: What? No. There was about to be a but...
Gandalf: You're a butt!
Dumbledore: Yes.
[he and Gandalf strike their rods against each other]
Metal Beard: You'll all be on your own! I'll be leaving this lost cause!
[Metal Beard jumps onto his ship and sails off Cuckoo Land]
Emmet Brickowoski: Why are you leaving?
Abraham Lincoln: A house divided against itself...would be better than this.
[Lincoln jumps into his seat and it suddenly takes off like a spaceship]
Emmet Brickowoski: Abraham Lincoln! You bring your spacechair right back here. Come on! Guys! We can still do this! [the Master Builder start throwing things at Emmet] Right?
Master Builder: He's not even a bit special.
Batman: [to Wyldstyle as they watch Emmet] Well, you were right about him being a ding-dong.
[the Master Builders continue to throw things at Emmet]
Master Builder #1: You're a huge disappointment.
Master Builder #2: Get him out of here.
[visibly sad and disappointed, Emmet turns and starts walking off]
Emmet Brickowoski: Well, at least it can't get any worse. [suddenly a golf ball is thrown into the dome] I was wrong!
[the golf ball crashes through the dome and lands in Cuckoo Land]
Superman: It's the Orb of Titleist!
[at that moment Bad Cop and his army of robots crash through into Cuckoo Land in their aircrafts]
Bad Cop: Breakthrough, it's the bad guys!
Emmet Brickowoski: Woh! How did he...?
Wyldstyle: Go! Run! Come on, everyone! Protect the special!
[Wyldstyle, Emmet, Vitruvius, Unikitty and Batman rush back into the dome]
Mermaid Lady: What's that on his ankle?
[Emmet looks down and we zoom in to see something attached to his ankle]
Knight: It's a tracking device?
[to his robots as he tracks Emmet]
Bad Cop: Take the Master Builders prisoners.
Gandalf: Oh, he led them right to us!
Emmet Brickowoski: Guys, no, no, no. I...it's not my fault.
Batman: [to Emmet as Bad Cops robots are attacking them] Oh, you are the worst leader I've ever seen. To the Batmobile! [the robots shoot at the Batmobile and it explodes] Dang it.
Wonder Woman: To the Invisible Jet! [the robots shoot at the empty space next to where the Batmobile was and that explodes too] Dang it!
Batman: Every man for himself!
[Batman jumps off the edge]
Superman: No! We must protect the Piece! Shaq, do you know what time it is?
Shaq: It's game time! [they build a device to throw their basket ball at the robots aircraft] Y'all ready for this? [they throw the ball and as it hits the robots aircraft they just turn towards them] Oh, no! They were ready for that!
Superman: IT DIDN'T BREAK!
Bad Cop: Because it's Kragled. [to his robots] Machine gun! Fire!
[they shoot at Superman with chewing gum making him splat to the ground stuck in the gum]
Superman: I can't move!
Green Lantern: Don't worry, Superman! I'll get you out of there.
Superman: No! Don't...
[as Green Lantern goes to rescue Superman his hands get stuck in the gum]
Green Lantern: Aah! Oh, my gosh. My hands are stuck. [he wriggles his legs and those get stuck in the gum too] My legs are stuck as well.
Superman: I super hate you.
[as the robots have got hold of Emmet]
Emmet Brickowoski: AAH! YOU'RE PULLING MY TORSO OFF!
Wyldstyle: Babe, help me get him out of here! (she decapitates a robot)
Batman: I said every man for himself. (he grabs a robot and strangles him)
Wyldstyle: Hey, you gotta be there for me.
Batman: Aaaah.. (pauses for a while) Fine! Fine, fine, fine! [reluctantly he goes to her aide and fights off the robots attacking Emmet] Fine. Fine. Fine...
Wyldstyle: I need you to have a better attitude about it!
Batman: I have a great attitude!
[Batman gets the tracker off Emmet and throws it at one of the robots]
Robot: Ow!
[Bad Cop picks up Emmet's tracker which is now attached to the robot]
Bad Cop: The Special's in the northwest quadron. We've got him cornered. [he looks down but all he sees is the robot with the tracker attached to his head smacking into a wall]
Robot: Ow! Ow! Ow!
Bad Cop: Where did he go?
Unikitty: Oh, no! They've hit our silly cloud stabilizers!
Wyldstyle: Let's go! We need to get Emmet out of here!
Emmet Brickowoski: Can't we build something? [suddenly the space guy comes over to them]
Benny: Hey, I'm Ben! But you can call me Benny! And I can build a spaceship: Watch this! [he starts building a spaceship and chanting along as he works] Spaceship! Spaceship! Spaceship! Spaceship! Spaceship...
Wyldstyle: No! You can't. The skies are surrounded.
Benny: That's okay, I didn't really wanna build a spaceship. Anyway, that's cool. [looking visibly disappointed he kicks his half built spaceship and it falls apart]
Unikitty: Well, where can we go where we can't be found?
[Emmet quietly mumbles]
Emmet Brickowoski: Maybe we could go underwater?
[Batman knocks him aside]
Batman: What if we went underwater?
Wyldstyle: Great idea, Babe!
Unikitty: Thank you, Batman! You're ideas are the best!
Emmet Brickowoski: But I just said that...
Wyldstyle: We could build a submarine!
Batman: A Batsubmarine, patent pending.
Unikitty: With rainbows!
Vitruvius: And dream catchers, in case we take a nap.
Benny: Like an underwater spaceship!
Emmet Brickowoski: Well, you can't build all of them at once.
[Wyldstyle, Batman, Unikitty, Vitruvius and Benny huddle together for a moment]
Wyldstyle, Vitruvius, Batman, Unkitty and Benny: Ready! Break!
[they all go off to build the submarine]
Emmet Brickowoski: Okay.
[as they build the submarine]
Unikitty: These are the colors I need: blue razzleberry and sour apple.
Batman: If anybody has black parts I need them, okay? I only work in black. And sometimes very, very dark grey.
Wyldstyle: Use the yellow bricks.
Emmet Brickowoski: Guys, can I help?
[Bad Cop continues to search for Emmet in his aircraft]
Bad Cop: Where is he?
[as the others continue to build the submarine Emmet holds up a piece of Lego]
Emmet Brickowoski: Anyone know what this is and do you need it?
Benny: I think we could use wings, rocket boosters...
Wyldstyle: Ooh, get your retro space stuff out of my area.
Emmet Brickowoski: Guys, hey? Just tell me exactly what to do and how to do it.
Vitruvius: Emmet, don't worry about what the others are doing. You must embrace what is special about you!
[suddenly Emmet gets and idea and smiles to himself]
[spotting Emmet on the submarine]
Bad Cop: There he is! All units, attack the sub!
[Bad Cop and his robots chase after the submarine and start shooting at it]
Wyldstyle: Emmet, get in here!
[the group takes the submarine towards the water as Bad Cop at his robots are chasing after them]
Bad Cop: Stop him! Stop him! [suddenly the submarine goes off the edge of a cloud and plunges down] Don't let him get to the water!
[as they get closer to the water]
Wyldstyle: Dive! Dive! Dive! Everybody in! We're going under!
[the submarine plunges into the water, we then see Cloud Cuckoo Land being destroyed by the robots and the Master Builders handcuffed and taken as prisoners]
Wonder Woman: Oh no.
[Unikitty watches sadly within the submarine as her home is destroyed]
Unikitty: My home. It's gone! I feel something inside, it's like, [angry] the opposite of happiness! I must stay positive. [she struggles within herself to remain positive] Bubblegums! Butterflies! [she looks out the window and sees more fallen debris from her destroyed home] Cotton candy!
[Unikitty begins to cry and Emmet goes over to comfort her]
Emmet Brickowoski: God, I'm so sorry, Unikitty. Do you wanna sit down and talk about it?
[he points to the double decker couch he's build behind them]
Batman: What... the hell... is that?
Emmet Brickowoski: It's a double decker couch, which seemed like a good idea at the time, but I now realize it's not super helpful. But it does, you know, it has cup holders, seats flip up with coolers underneath.
[they all look at him for a moment]
Batman: You are so disappointing on so many levels.
Vitruvius: Why are my pants cold and wet?
Wyldstyle: Ew!
Vitruvius: Uh...
[suddenly the sub starts to fill up with water]
Unikitty: The walls are crying!
Benny: We're falling apart at the seams!
[as the submarine starts to fall apart]
Batman: This is not how Batman dies!
[as the submarine fills with water Emmet starts to drown]
Wyldstyle: Emmet! Hold on! Hold on!
Emmet Brickowoski: Wyldstyle!
Wyldstyle: Deep breath! [inhales] Deep breath, everybod...!
[suddenly as the submarine sinks it explodes, above the water Bad Cop circles in his aircraft]
Bad Cop: Micro managers, what's going on down there?
Robot: Scanning submarine wreckage. No survivors detected.
Bad Cop: Scuba Cops, dredge the entire ocean if you have to. We have go to find that piece. [the scuba cops dive into the ocean to search for the Piece of Resistance] Let's get these prisoners back to Lord Business and give him the good news: the Special is no more.
[the captured Master Builders are taken to Lord Business's Think Tank]
Lord Business: Hello, everybody! Superman. Wonder Woman, I had no idea you'd be here. Mr. Shaquille O'Neal. Greetings, all! Welcome to my Think Tank!
[Superman gets into strapped to a chair]
Superman: All the Master Builders you've captured over the years, you brought them here.
Lord Business: You're a very perceptive person, Superman. They come up with all the instructions for everything in the universe. Robots!
[the robots strap a device to Superman's head]
Superman: No! No! [then his chair shoots up to the top] NOOOOOOOOOOOOOOO!!!! AAAAAAH!! Can't get much worse than this.
Green Lantern: Uh...hello, neighbor.
Superman: Oh no.
[we see Green Lantern is strapped in the chair next to Superman's]
Green Lantern: It's Green Lantern! Oh, my gosh. We're roommates! How crazy is that?
Superman Does anyone have some Kryptonite that they could give me?
[as the other captured Master Builders are being strapped into the Think Tank]
Lord Business: Woah, woah, woah, woah. Where is the Special?
Bad Cop: The Special and the Piece of Resistance are at the bottom of the ocean.
Lord Business: Wait, are you telling me you don't have him?
Bad Cop: Sir, my scuba team is looking for his remains as we speak.
Lord Business: Bad Cop, he could still be alive! The Piece could still be out there!
Bad Cop: The only remanent of the Special was a double decker couch.
Lord Business: Wait, hold up. A double decker couch?
Bad Cop: Yes, sir.
Lord Business: Really? So it's like a bunk bed couch? Is that what it's like? That's weird. If you're sitting in the top middle, how are you gonna get down without climbing over someone? If you're sitting on the bottom, and you're watching TV, are you gonna have to watch through a bunch of dangling legs? Who's gonna want to sit on the bottom? It is literally the most useless idea I have ever heard.
[cut to the double decker couch floating on the sea and suddenly Emmet and the others pop out of their hiding place from under the flip up seats]
Vitruvius: Well, we're still alive.
Unikitty: Yeah!
Wyldstyle: The double decker couch! It wasn't totally pointless after all.
Benny: It's the one thing that stayed together.
Vitruvius: I always believed in you, Emmet.
Batman: I don't mean to spoil the party, but does anyone else notice we're stuck in the middle of the ocean on this couch? I mean, it's not like a big gigantic ship is just gonna come out of nowhere and save us... [suddenly a big gigantic ship becomes visible as it comes over to them] ...My gosh!
[We see it's by Metal Beard on his ship.]
Metal Beard: Avast! Matey's!
[Metal Beard grabs the couch and puts it on his ship]
Benny: Metal Beard! I thought you said we were a lost cause!
Metal Beard: Ye are! Did ye not hear me whole story circumscribing the folly of this whole enterprise?
Batman: Well, it's kind of hard not to hear when you're yelling everything.
Unikitty: So why did you come back?
Metal Beard: This bedoubled land couch.
[Everyone turns to look at Emmet's double decker couch]
Metal Beard: I watched Lord Business's forces completely overlook it. Which means we need more ideas like it!
[beaming with joy]
Emmet Brickowoski: Oh, thank you.
Metal Beard: Ideas so dumb and bad that no one would ever think that they could possibly be useful.
[Emmet's smile disappears]
Emmet Brickowoski: Oh, thank you.
[everyone looks at Emmet]
Vitruvius: So, Special, what do we do?
[Emmet stares back at them for a moment before replying]
Emmet Brickowoski: Uh...well, what's the last thing Lord Business expects Master Builders will do?
Benny: Build a spaceship?
Vitruvius: Kill chickens?
Unikitty: Marry a marshmallow!
Metal Beard: Why, this!
[Metal Beard transform into singing radio and starts playing "How Ya Gonna Keep 'em Down On The Farm"]
Emmet Brickowoski: No! It's follow the instructions.
[everyone sighs with disappointment]
Benny: Don't like that.
Unikitty: Sounds weird.
Emmet Brickowoski: No. Now, listen. Wait, listen. Guys, you're all so talented and imaginative, but you can't work together as a team. I'm just a construction worker, but when I had a plan and we were working together, we could build a skyscraper. Now you're Master Builders, just imagine what could happen if you did that. You could save the universe.
Vitruvius: Well said, Emmet. Well said.
Emmet Brickowoski: Really?
Metal Beard: It be a fine speech there, laddy.
Emmet Brickowoski: Okay. Now somebody get me some markers! Some construction paper! And some glitter glue! [Emmet stands in front of the instructions he's drawn] I call this, "Emmet's plan to get inside the tower, put the Piece of Resistance on the Kragle and save the world." I've build a hundred just like them back in the city. If we could just get in there, I know where all the air ducts and wiring are located. I can get us anywhere.
Vitruvius: How will we get inside?
Emmet Brickowoski: In a spaceship.
Benny: Spaceship!
[Benny rushes off excitedly to build a spaceship]
Batman: Great idea, a Bat spaceship.
Emmet Brickowoski: No. They're expecting us to show up in a Bat spaceship, or a pirate spaceship, or a rainbow sparkled spaceship.
Batman: One of those sounds awesome to me.
Emmet Brickowoski: My idea is to build a spaceship that's exactly like all the other Octan Delivery Spaceships.
Benny: So not the special spaceship that I'm...I'm building for all of you right now?
Emmet Brickowoski: Sorry, Benny. Maybe next time.
Benny: Ooh, you're really letting the oxygen out of my tank here!
[he kicks his spaceship and it falls to pieces]
Batman: Yeah, but according to your precious instructions, this ship needs a hyperdrive. We don't have that part.
Benny: Maybe we could find one!
Batman: What do yo think, a spaceship's just gonna appear out of the blue? [suddenly a spaceship appears behind them] Are you kidding me?! The same thing!
[Star Wars main theme: the Millennium Falcon shows up and stops next to Metal Beard's ship]
Han Solo: (opens the cockpit) Chewie, we're supposed to be half way to Naboo for a sweet party right now. This hyperdrive keeps malfunctioning, taking us to loser systems like this.
[Chewbacca emerges from an upper hatch and growls, C-3PO emerges from a bottom hatch]
C-3PO: [he points to the ship] Captain Solo, we must go. You know how perturbed I get if we are not punctual.
Han Solo: Droid's right. Let's roll!
Lando: Now, hold on, Han. [looking at Wyldstyle] This might be the right galaxy after all, because I see a heavenly body.
[Star Wars romantic theme plays]
Wyldstyle: Ooh, woh. I have a boyfriend. And it is super serious. Right, babe?
Batman: Of course it's serious.
Wyldstyle: Yeah.
Batman: [to Lando] Got room for just one dude?
Wyldstyle: Whoa, babe!
Lando: If he's a cool dude like you.
Wyldstyle: You're trying to bail on us!
[she hits Batman]
Batman: I'm not trying to bail on Emmet's team!
Wyldstyle: You asked if you could go with them on their party ship!
Batman: That thing is filled with bon vivants.
Wyldstyle: You speak French now?
Batman: Babe, look. If this relationship is ever gonna work between us, I need to feel free to party with a bunch of strangers whenever I feel like it.
Wyldstyle: What? Babe?!
[he uses a grappling hook to board the spaceship]
Batman: I will text you.
Lando: Where did you get that sweet space cape, brother?
[the spaceship takes off]
Han Solo: It's party time!
[Wyldstyle watches Batman leave in sadness and shock]
Wyldstyle: Babe?
[she turns and begins to weep, Emmet tries to comfort her]
Emmet Brickowoski: Wyldstyle, you're such an amazing person, and you know, if Batman can't see that then he's just...well, he's just as blind as a guy who's eyes stopped working. And I'm gonna tell you something, Batman is the worst person I've ever met. [suddenly Batman appears behind them with the Millennium Falcon's hyperdrive]
Batman: Need a hyperdrive?
Emmet Brickowoski: No way!
Wyldstyle: Babe!
Emmet Brickowoski: I knew it! I knew that.
Wyldstyle: You really had me there.
Batman: Those guys were so lame. All they did was play space checkers, plus it turns out that hairy one's a dude, and the metal one too, all dudes.
[Benny floats up into view from below]
Benny: But won't they notice their hyperdrive is missing?
[we see a repeat of The Empire Strikes Back where the Millennium Falcon is escaping from the asteroid]
Han Solo: Come on, Chewie. Hit the hyperdrive!
[suddenly the spaceship stops functioning, causing it and the Star Wars characters to be eaten by an asteroid worm, screaming is heard; cut back to the ship]
Batman: Nah, they'll be fine. [following Emmet's plan, the group work together to build a spaceship]
Emmet Brickowoski: Step one: [instructing the others] Alright, we need a blue two piece unit over at the... [Emmet notices Unikitty putting flowers into the spaceship] Unikitty, you're supposed to follow the instructions, remember?
Unikitty: Sorry!
Wyldstyle: [picking up a piece of Lego as they follow the instructions] Oh, this give me the jeebeeze!
Batman: What do I even...? I can't...! [he throws the piece of Lego aside in frustration; after they've build the spaceship]
Emmet Brickowoski: Nice. Step two; we pilot the ship to the service entrance so we can get past to the dangerous, but also kind of cool, Laser Gate.
[in their spaceship they get to the Octan service gate, Batman and Benny are sat in the driver's seat]
Robot: Space ID?
Batman: I have a drive-on.
Robot: Who are you here to see?
Batman: I'm here to see your butt.
Robot: Is that a last name "Butt", first name "Your", or is it...? [Batman throws a Batarang at the Robot decapitating him] Oh, my gosh!
[Batman and Benny laugh then Batman throws another Batarangs at the gate button but fails to hit it]
Batman: Pow! [he throws another which still doesn't hit it] Wham! [he throws another and misses again] Kezap! [he then repeatedly throws the Batarangs until it finally hits the button making it go green, just like he does in Batman Arkham games] First try!
[after they enter into Octan Tower]
Emmet Brickowoski: Step three; we break into Lord Business's office and we'll plunder his collection of relics for disguises. [they break into Lord Business's office and use his relics to disguise themselves] Step four; Benny and Metal Beard sneak their way into the Master Control Room.
[as Metal Beard and Benny break into the control room]
Computer: Motion sensors triggered in Sector 12.
Robot: Ten-four.
Benny: Uh-oh!
Robot: [two security guard robots go to investigate, Metal Beard and Benny quickly hide, Metal Beard transforms into a photocopying machine] Are you thinking what I'm thinking?
Robot 2: Oh, oh, oh, oh, oh, oh, oh, oh!
Robot: [the other robot jumps onto the photocopying machine] Do it! [the robot starts photocopying his bottom, both robots laugh and suddenly Metal Beard transforms back and destroys the two robots]
Benny: Metal Beard, that was awesome!
Metal Beard: First law of the sea, "never place your rear end on a pirate's face."
[as he speaks the camera shows a picture of a Lego figure butt and a cancel sign over it. We also see Metal Bear's face on an angry emoticon]
Emmet Brickowoski: Once inside they'll use their technical know-how to disable the Kragle shield.
[Metal Beard and Benny get inside the control room to disable the computer]
Computer: I am the computer.
Benny: Cool! A talking computer! [Benny starts tapping into the computer] Please disable the shield systems.
Computer: Of course. There are no movies in your area with that title.
Benny: Ahh!
Emmet Brickowoski: Step five; Vitruvius will provide lookout to make sure we're not being followed.
[Vitruvius looks through the binoculars, but being blind he's unaware that he's standing in front of a wall]
Vitruvius: Okay.
Emmet Brickowoski: Step six; Batman and Unikitty go into the Board Room to make one last change to Lord Business's plan.
[inside the Board Room Lord Business is holding a meeting]
Lord Business: I move that we freeze the universe. Could I get a second on that?
[suddenly Bruce Wayne enters the room]
Bruce Wayne: I second. Bruce Wayne, CEO of Wayne Enterprises.
[cut to the group as they are going through their plan; Batman pretends he doesn't know who his alter ego is]
Batman: Bruce Wayne? Uh...who's that? Sounds like a cool guy.
[the other stares, all clearly aware who Bruce Wayne is, stare at him in silence]
[Bruce Wayne and a disguised Unikitty enter Lord Business's Board Room]
Bruce Wayne: We'd like to invest in your company. Your weapon to control the universe sounds super sweet, I must say.
Lord Business: It is indeed super sweet.
Bruce Wayne: Cool! What kind of sound system does it have?
Lord Business: Uh...sound system? Well, I mean, we have an iPod shuffle.
Bruce Wayne: Wait a second. You're telling me that you have a machine to control the universe and you can't listen to tunes and surround sound?
Unikitty: Embarrassing!
Lord Business: Well, we...I mean, we...we need to get that done. I want eight foot speakers.
Bruce Wayne: Great call.
Lord Business: Yeah. I want speakers that you can hug with your arms and your legs, and just feel the beat.
[cut to Lord Business's robots instructing the captive Master Builders in the Think Tank]
Robot: Listen up, we need new instructions for a speaker system for the TAKO.
Gandalf: We'll never help...! [suddenly device attached to their heads initiates and they all start coming up with the instructions] Whatever you say, boss!
Emmet Brickowoski: Then once the instructions are printed, Wyldstyle and I will enter the Kragle room to place the thing on the other thing and save the universe. [cut to the group having their planning meeting] Whoa, whoa, whoa. Hey, I didn't draw that. [points to a drawing of himself exploding as he saves the universe] Is that me exploding?
Vitruvius: Uh...I didn't mention that earlier, when you reunite the Piece with the Kragle it might explode?
Emmet Brickowoski: No! But it might not, right?
Vitruvius: Sure, sure, sure. Just go with that.
[back at Octan Tower, Emmet and Wyldstyle disguised as a robots, deliver the speakers to the control room]
Robot: Attention everybody, incoming speaker delivery.
[Emmet looks in fear at the TAKO device and suddenly misses his footing and drops the speaker]
Emmet Brickowoski: Ow!
[the other robots look at them with suspicion]
Robot #1: Who are you two?
Wyldstyle: [trying to sound like a robot] We are transfers from downstairs.
Robot #1: What? Excuse me?
Emmet Brickowoski: [Emmet then speaks in a pretend robot voice] You're robot voice sounds an awful lot like a human voice?
Wyldstyle: Give me a break. I've never been a robot before.
Emmet Brickowoski: What do you mean? You have always been a robot!
[as the other robots get ready to attack them]
Emmet Brickowoski: No, no, no. Do not listen to her.
Robot #1: What are your robot serial numbers?
[as the robots stare at them suddenly Emmet starts humming the tune to "Everything is Awesome!" then he dances and turns]
Emmet Brickowoski: Everything is awesome!
[the robots back down]
Robot #1: No way! This is my jam.
Robot #2: This is also my jam.
[the robots starts singing and dancing]
Robots: Everything is awesome. Everything is cool...
[Emmet starts joining in with them, he turns to Wyldstyle indicating for her to also sing along]
Wyldstyle: I don't want to sing the song. [the robots suddenly get ready to attack them when Wyldstyle joins in and sings] Everything is awesome! Everything is cool when you're part of a team. Everything is awesome when you're living out a dream. [the robots start heading in one direction, Wyldstyle and Emmet quickly sneak away] Quick, let's go.
[after they get passed the robots and start climbing up a vent]
Emmet Brickowoski: Mm, I thought you didn't like that song.
Wyldstyle: I don't.
Emmet Brickowoski: Mm-hmm. I know you put on this tough act, but I don't think you're as mean as your trying to seem.
Wyldstyle: No, I'm not mean. What are you talking about?
Emmet Brickowoski: I'm just saying you were all, "He's not the Special, Vitruvius. He can't possibly be the Special! This guy, are you kidding me?" I don't think that's you, the real you, I mean.
[Wyldstyle sees the Kragle in the TAKO device through the ventilation bars]
Wyldstyle: Look, Emmet, I...I wanted it to be me, okay? I wanted to be the Special. And I know that sounds super mature, it's just ever since I heard the prophecy I wanted to be the one. I was right there in that construction site, right on top of it, and then...it turned out to be you.
Emmet Brickowoski: That night in the city when you thought I was the Special...and you said I was talented and important, that was the first time anyone that ever told me that. And it made me wanna do everything I could to be the guy you were talking about.
[Wyldstyle takes off her robot disguise]
Wyldstyle: Lucy.
Emmet Brickowoski: What?
Wyldstyle: That was my real name. You asked earlier and it's...Lucy. [Emmet takes off his robot disguise] I really like that name.
[as the two of them are about to have an intimate moment and touch hands suddenly Batman appears]
Batman: Hey, what are you two losers talking about?
Wyldstyle: What? What? Oh, nothing.
Batman: I thought I'd help you guys. Left the weird cat thing to stall.
[we see Unikitty in the Board Room trying to distract the robots]
Unikitty: Business, business, business. Numbers. Is this working?
Robot: Yes.
Unikitty: Yay.
Emmet Brickowoski: There's Bad Cop.
[we see Bad Cop looking happy and singing to himself, back in the vent]
Bad Cop: Oh Danny boy the pipes
Wyldstyle: Okay, wait for my signal. Good luck, Emmet.
[Wyldstyle turns and stars to rush off]
Emmet Brickowoski: Lucy? [she turns to face him] I guess this might be goodbye.
Wyldstyle: I...I don't like goodbyes. Let's just call this, "see you later, alligator."
Emmet Brickowoski: See you later, alligator?
Wyldstyle: After a while, crocodile. [looking sad, Wyldstyle turns and rushes off, Batman looks at Emmet]
Batman: Who's Lucy?
Emmet Brickowoski: Batman, when we get inside there's gonna be audio sensors everywhere. [Emmet shows him the instruction he'd drawn up earlier] You have to be really, really quiet.
Batman: Don't worry, Dad, I read your dumb instructions. Stop yelling at me.
Emmet Brickowoski: [into the walkie-talkie] Benny, what's the status with the shield?
[in the control room Benny is quickly working in panic trying to disable the Kragle shield on the computer]
Benny: Oh, yeah, yeah. No, it's going great. It's just going great! If somebody would listen to me$
Computer: Downloading latest episode of "Where Are My Pants?"
Benny: Where are you getting pants from? You know what I want?
Bad Cop: The pipes are calling
[Bad Cop gets a phone call]
Bad Cop: Bad Cop.
Robot: Hi. This is Lord Business's assistant, he would like you to come to his office immediately.
Bad Cop: Copy that. Thanks.
[as Bad Cop leaves we see the robot voice on the other end of the line is Wyldstyle who is hiding around the corner waiting for Bad Cop to leave]
Wyldstyle: You are welcome, sir. [as the door of the security station are about to close Wyldstyle throws her phone at the door stopping it from closing]
Robot: Hey, who is that? [from the vent Emmet sees Wyldstyle knocking the robots out in the security room]
Emmet Brickowoski: That's the signal, but the shield is still up!
Batman: We'll wing it. [Emmet looks blank faced] It's Bat pun.
Emmet Brickowoski: [as they make they way to the Kragle, Emmet whispers into the walkie-talkie] Benny, disable the shield.
Benny: Disable the shield!
Emmet Brickowoski: Now.
[back in the computer room Benny is frantically trying to get the computer to disable the shield]
Benny: Disable the shield!
Computer: Searching for Albanian restaurants.
Benny: What? No! I never once said anything...
Computer: I don't understand what you mean.
Benny: Disable the shield!
Emmet Brickowoski: Benny, what's going on?
Benny: [to the computer] Disable the shield! Come on! You are undermining me!
Computer: Which phrase would you like me to underline?
Benny: DISABLE THE SHIELD?
Metal Beard: Let me try. [to the computer] Be ye disabling of yond shield.
Computer: Disabling shield.
Benny: What?
[as the Kragle shield is disabled Emmet stands next to it and whispers into his walkie-talkie]
Emmet Brickowoski: Okay, in ten...nine...eight...seven...six...five...four...three...two...one. Let's do this thing. [just as Emmet is about to attach the Piece of Resistance to the Kragle, which is the cap tot he tube, Bad Cop and his robots enter] Lucy! [Wyldstyle goes to attack them but she's knocked out] Lucy! [the Kragle shield is then turned on again] No!
[the robots point their guns at Batman and holds up his hand in surrender]
Batman: Oh, man.
[Benny and Metal Beard are captured in the computer room]
Benny: Oh no!
[Unikitty is also captured in the Board Room]
Unikitty: Uh-oh!
[Vitruvius has wandered into the Think Tank]
Vitruvius: Sneaking around the corner. [suddenly he falls to the ground flat on his face]
Lord Business: Vitruvius, I see you've accidentally wandered into my Think Tank. And by the way, I found a few of your friends. By which I mean, all of them!
[Vitruvius turns as Emmet, Lucy, Batman, Benny and Metal Beard are brought in]
Emmet Brickowoski: Sorry.
Lord Business: Acceptable work, Bad Cop.
Bad Cop: Thank you, sir.
Lord Business: Robots, destroy this old man at once.
Vitruvius: Did you just call me old?
Lord Business: Yeah. So what?
Vitruvius: Well, Junebug, I really prefer the word "experienced!" [suddenly Vitruvius starts attacking the robots and manages to knock all of them out, all the captive Master Builders cheer for him] Ha-ha! You see, Emmet. A corrupted spirit is no match for the purity of imagina... [suddenly Lord Business pops his head off with a 2007 nickel]
Emmet Brickowoski: Vitruvius! No! [Vitruvius's decapitated head rolls over towards Emmet] Vitruvius...
[Vitruvius's eyes open]
Vitruvius: My sweet, Emmet, come closer. You must know something about the prophecy.
Emmet Brickowoski: I know, I'm doing my best. But I-I don't...I don't...
Vitruvius: The prophecy...I made it up.
Emmet Brickowoski: What...?
Vitruvius: I made it up. It's not true.
Emmet Brickowoski: But that means I'm just...I'm not the Special?
Vitruvius: You must listen. What I'm about to tell you will change the course of history. [just as he's about to speak the light in Vitruvius's eyes goes out and he dies]
Emmet Brickowoski: No...! No! [the group looks visibly sad as they are led away by the robots]
Lord Business: Hey, not so special anymore, huh? [the robots strap each of the group into one of the Think Tank seats] Well, guess what? No one ever told me I was special. I never got a trophy just for showing up! I'm not some special little snowflake. [the micro-manager robot picks up Emmet and straps him onto a battery] Robots, bring me the Sword of Exact-Zero!
Robots: Yes, Lord Business.
Lord Business: [the robots hand Lord Business an Xacto razor and he walks over to Emmet] Must be weird, one minute you're the most special person in the universe. The next minute, you're nobody! [suddenly Lord Business uses the razor to cut the Piece of Resistance from Emmet's back] Oh, I have a nice spot for this in my relic room. [he suddenly throws the Piece of Resistance out the window] Uh-oh, my mistake! There it goes!
Wyldstyle: No!
Lord Business: Bye-bye, forever! [the Piece of Resistance falls into the abyss] Well, I guess there's only one thing left to do! [he turns to his robots] Release the KRAGLE!! Computer?
Computer: Yes, sir.
Lord Business: Set the electric shocker to 100 Mississippi.
Computer: No problem.
Lord Business: Then terminate everyone.
Computer: Already on it.
Lord Business: Emmet, that should give you enough time to witness the first location to be Kragled. Your home town!
Emmet Brickowoski: No!
[Lord Business gets onto the Kragle device]
Lord Business: Bad Cop, unfortunately I'm gonna have to leave you here to die.
Bad Cop: What? [Bad Cop is suddenly surrounded by robots] Sir, I...
Lord Business: It's not personal, it's just business. Lord Business. Ciao! [the Kragle device shoot up to the top of the ceiling disappearing with Lord Business, then the computer starts counting down]
Computer: Beginning zapping termination in ninety-nine Mississippi, ninety-eight Mississippi, ninety- seven Mississippi, and so on.
Lord Business: [Lord Business flies over Bricksburg in his aircraft] Attention, everyone. This is President Business. Attention, everyone. This is President Business. [the citizens of Bricksburg stop and look up at Lord Business's aircraft as it hovers over the city] Hello! Hi! Welcome to Taco Tuesday! Don't worry about this big black violet thing that's blocking out the sun. What you need to worry about is this question that I'm about to ask you. Who wants a taco?! [Mexican music starts blaring out as everyone in the city cheers] Yeah! I know! Taco! Taco! Go crazy! Alright, everyone. Act normal. [as everyone is busy dancing and cheering Lord Business releases several Kragle devices from his aircraft] Perfect. Now, everybody say freeze! [as he starts spraying them with glue some people start running off and screaming] So I guess running around and screaming is normal. Micro-manager, commence micro-management!
Micro-Manager: Commencing micro-management. [the micro-managers starts spraying everyone with glue and freezing them, back at the tower Emmet watches this in horror on the big screen]
Bricksburg Citizen: Please! Please, won't somebody help us!
Benny: Emmet, you'll...you'll think of something, right? Like you always do.
Emmet Brickowoski: Didn't you hear him? The prophecy's made up. I'm not the Special. To think for a moment I thought I might be.
Vitruvius: Emmet. [suddenly Emmet hears Vitruvius's ghostly voice]
Emmet Brickowoski: Who said that?
Vitruvius: I did. [Vitruvius's ghostly forms appears behind Emmet] I am ghost Vitruvius. Ooooh! [he glides over to face Emmet] Emmet, you didn't let me finish earlier because I died. The reason I made up the prophecy was because I knew that whoever found the Piece could become the Special. Because the only thing anyone needs to be special is to believe that you can be. I know that sounds like a cat poster, but it's true. Look at what you did when you believed you were special. You just need to believe it some more.
Emmet Brickowoski: But how can I just decide to believe that I'm special, when I'm not?
Vitruvius: Because the world depends on it. Ooooh! [suddenly the ghostly form of Vitruvius starts to glide away]
Computer: Zapping termination in thirty-five Mississippi...
Emmet Brickowoski: What?!
Computer: Thirty-four Mississippi, thirty-three Mississippi, thirty-two Mississippi, thirty-one Mississippi, thirty Mississippi, twenty-nine Mississippi, twenty-eight Mississippi, twenty-seven Mississippi, twenty-six Mississippi, twenty-five Mississippi... [as the count down continues Emmet gets and idea, manages to dislodge the battery from it's holding place and rolls himself with the battery toward the window]
Wyldstyle: Emmet! What are you...?
[Emmet rolls himself towards the edge of the broken window and looks down into the abyss]
Emmet Brickowoski: Woh! [he looks back at Wyldstyle] Lucy!
Wyldstyle: Wait! What are you...? What are you...?
Emmet Brickowoski: Now it's your turn to be the hero. [realizing what Emmet is planning to do]
Wyldstyle: No!
Emmet Brickowoski: See you later, alligator.
Wyldstyle: Don't! [Emmet jumps out the window] No! Emmet! [as the computer count down continues Emmet starts falling into the abyss]
Computer: Six Mississippi...
Emmet Brickowoski: Aaah!
Computer: Five Mississippi, four Mississippi, three Mississippi, two Mississippi... [as Emmet gets nearer to the abyss the battery he's strapped to snaps off] One Mississippi, zero. Mission error. Termination failure. [as the detonation sequence deactivates the Master Builders are freed from their captivity]
Wyldstyle: Emmet! [Wyldstyle rushes over to the edge of the window and look down into the abyss] No! [the other Master Builders gather round]
Gandalf: He...he saved us.
Unikitty: Well, what do we do now? There's gotta be a bright side here somewhere?
Superman: Does anyone have any ideas?
Benny: Emmet had ideas.
Metal Beard: Arr, if only there were more people in the world like he? [suddenly Wyldstyle has an idea and looks round to the screen showing the citizen of Bricksburg as they are getting glued]
Wyldstyle: Meet me downstairs in ten seconds! [ten seconds later; at the sound stage where they are filming "Where Are My Pants?"]
Actor on TV Show: Honey, where are my pants? [suddenly the Master Builders crash into the sound stage]
Unikitty: Hi!
Wyldstyle: Hey, guess what? Found your pants! Series is over! [she throws the pants into the actors face and kicks him out of the way] Benny, send this out to everyone in the universe. 1980 something technology?
Benny: Now you're taking! 
[Benny goes over to the machine and starts broadcasting Wyldstyle to the universe, including Bricksburg who are all rushing around trying to not get glued]
Wyldstyle: Hey, everybody. You don't know me, but I'm on TV, so you can trust me. I know things seem kind of bad right now, but there is a way out of this. This is Emmet. [footage of Emmet is shown] And he was just like all of you. A face in the crowd, following the same instructions as you. He was so good at fitting in, no one ever saw him. And I owe you an apology, because I used to look down on people like that. [we see Wyldstyle's broadcast being watched by all Lego citizens across the realms in the universe, including Middle Zealand where a knight is reading out form a scroll]
Knight: I used to think they were followers with no ideas or brains.
Wyldstyle: Because it turns out Emmet had great ideas. And if they seemed weird, and kind of pointless, they actually came closer than anyone else to saving the universe. And now we have to finish what he started by making whatever weird thing pops into our heads. All of you have the ability inside of you to be a ground breaker. And I mean literally, break the ground! Peel off the pieces, tear apart your walls! Build things only you could build, defend yourselves! We need to fight back against President Business's plans to freeze us! [the Lego citizens start putting Lego pieces together and building things]
Wyldstyle: Today will not be known as Taco Tuesday, it will be known as Freedom Friday! [the citizens start cheering] But still on a Tuesday! [suddenly they are interrupted as the robots appear in the studio]
Robot: End of the line. [just as the robots are about to attack they are quickly killed off by Bad Cop]
Wyldstyle: Bad Cop?
Bad Cop: I hope there's still a Good Cop in me somewhere. [he turns his face to the Good Cop face, which is now blank, and draws eyes and a mouth with a red marker]
Good Cop: I'll hold these guys up. You go stop 'em. Yay!
Metal Beard: Great idea. But how will we get there? [suddenly Benny starts having an idea]
Benny: I could uh....I could build a...I could build a....I could build a spaceship! [he looks around to see if anyone disagrees] You're...you're not...you're not gonna say no?
Good Cop: Build away, whatever your name is.
[Benny jumps around in excitement as he quickly assembles a spaceship]
Benny: Spaceship! [the team then fly the spaceship through the different realms] Spaceship! Spaceship! Spaceship! Spaceship! Spaceship! [they are then spotted by the robots]
Robot: All units, attack that spaceship. [the robots chase after the spaceship in their aircrafts and start shooting at it]
Benny: Spaceship!
[Benny quickly steers the spaceship away from sight]
Robot: Where did he go? [suddenly the spaceship flies up through the robots aircrafts destroying them]
Benny: Spaceship! [as they fly over Bricksburg]
Unikitty: Wyldstyle, look. It's the citizens! [the citizens have build aircrafts which they are using to attack Lord Business's robots]
Abraham Lincoln: And don't forget us Master Builders! [from inside his aircraft Lord Business watches all the citizens fighting back on the TV monitors]
Lord Business: What is going on? Just stop building that stuff! Just stop it! [as they fly over Bricksburg]
Wyldstyle: This might actually work.
Metal Beard: It was your speech which roused this hearty crew.
Wyldstyle: If only Emmet were here to see this. He'd day something adorable, like... [it cuts to Emmet as he continues to fall through the abyss]
Emmet Brickowoski: Aaaaaaaaaaaaaaaaaaahhhhhhhhhhhhhhhh!!!!!!!!!!!!!!!!!!!!! Am I just gonna keep falling forever??!!!?????!!!!!!!! [finally Emmet lands somewhere and it cuts to blackness]
[finally Emmet becomes conscious he finds he can't move but is able to think]
Emmet Brickowoski: Is this another vision? Where am I? [he sees the sign for Octan Tower] Is that the office tower? [we see Emmet has fallen on the ground in a basement where all the different Lego realms including Bricksburg have been assembled on a large table] Bricksburg! [he suddenly feels the ground shaking as if someone has taken a giant footstep] What was that? [we see a human boy, Finn, running around the basement heading towards Emmet] No, no, no, no! NO?
[Finn accidentally steps on Emmet as he carries on running, we then see Finn is playing with the Lego set and actually carrying the spaceship Benny had built as if it's flying]
Finn: Spaceship! Spaceship!
Emmet Brickowoski: What in the world is that? [he continues to watch Finn playing with the Lego spaceship] It's...adorable. [suddenly Finn notices Emmet lying on the floor] Uh-oh! [Finn comes over to pick Emmet up] No! No! No, no, no, no! Hey, don't eat me! Don't eat me! Do not eat me! Please!
[Finn gently picks Emmet up and looks at him]
Finn: Hi, Emmet.
Emmet Brickowoski: Uh...hi? Is this The Man...? [suddenly the basement door opens and the shadow of a man appears at the top of the stairs and he starts walking down the stairs] The Man Upstairs. [when the man finally reaches the last step we see it's Finn's father wearing a business suit and looking annoyed]
The Man Upstairs: What happened? [as he sees all the different Lego pieces all over the place] No, no, no. This is a disaster. Why...why is...? What? What?! What?! The-the...why is the dragon on top of the luxury condo development?
Finn: I was just playing and...
The Man Upstairs: Look, I know it's hard to understand. But this is Dad's stuff, okay? All of this that you see before you is all your father's. And everything is thought out, there's... [he looks around and sees the top of Octan Tower missing]
The Man Upstairs: What did you down here? Did you take the top off of the tower?
Finn: It was an accident.
The Man Upstairs: You accidentally, expertly, carefully took the entire top off of that tower?
Finn: Yes.
The Man Upstairs: You know the rules, this isn't a toy!
Finn: Um...it kind of is.
The Man Upstairs: No, actually it's a highly sophisticated inter-locking brick system.
Finn: But we bought it at the toy store.
The Man Upstairs: We did, but they way I'm using it makes it an adult thing.
Finn: The box for this one said "Ages 8 to 14"!
The Man Upstairs: That's a suggestion. They have to put that on there.
Finn: Because maybe we won't be able to resist playing with all this.
The Man Upstairs: Look, I moved your stuff over near to the decorations. All those bricks, you can build anything you want. [Emmet sees the larger Lego pieces piled together in a box, he notices Finn looking sad] Finn, we're gonna play a little game. It's called "let's put everything back the way you found it."
Finn: But, Dad, you don't understand...
The Man Upstairs: So I can make things they way they're supposed to be. [he turns goes over to the nearby table and picks up a tube of Krazy Glue] Permanently.
Emmet Brickowoski: More Kragles?! [back in the Lego world, Lord Business tries to stop the citizens from fighting back]
Lord Business: This rebellion ends right now! [he releases a bunch of micro-managers onto the city and they start attacking, then we see Finn's father is actually the micro-manger as using the Krazy Glue to stick a flying Lego truck the onto the Lego board]
Bricksburg Citizen: Oh, no! [then we see a Lego fireman who's build a machine out of his fire truck to fight off the micro-managers]
Fireman: Ha-ha! Fire in the hole! [Finn's father goes to pick up the fireman's truck] Wait! What's happening? No, wait! No, we're going down! [Finn's father destroys the assembled fire truck Lego piece] No! [we see one of Emmet's neighbors, Sharon, who's build a sled with her cats tied to the front as they rush away from the micro-managers]
Cat: Meow. Meow.
Sharon: Hold on, dear, we're coming for you. [the micro-manager gets her which is in fact Finn's father gluing Sharon to the Lego board] Ah!
Emmet Brickowoski: Stop!
Sharon: Oh, no!
[Emmet watches in horror as Finn's father continues to glue the Lego pieces]
Metal Beard: Arr, there be too many micro-managers!
[Finn's father is holding Benny's spaceship in his hand]
The Man Upstairs: What am I holding here?
Finn: It's a battleship.
The Man Upstairs: No, it's a hodge-podge that's what it is. What's Batman doing on it? [he throws Batman off the spaceship then picks up Metal Beard] What is this? A robot pirate? [he throws Metal Beard down and he lands next to Batman]
Batman: Dang it.
[Emmet watches all this in horror as Finn holds him]
Emmet Brickowoski: Stop! Stop it! No! Stop it! Stop!
[Finn's father notices Emmet in Finn's hand]
The Man Upstairs: You got glue all over that construction worker. Here, give that to me. [he takes Emmet from Finn]
Emmet Brickowoski: Stop it! Stop it! Stop it! [he looks down and sees all his friends scattered all over the Lego board] All of those are my friends! No! Stop it!
Metal Beard: We were a hearty crew, but it be...it be over.
Emmet Brickowoski: No! [Finn's father turns Emmet around in his hand and Emmet notices the Piece of Resistance on the floor] The Piece of Resistance! I can still save them.
The Man Upstairs: Let's get this gunk off this construction worker. [he places Emmet on his work table]
Finn: He's not just a construction worker, Dad. He's the hero.
The Man Upstairs: No, he's not. He is a ordinary, regular, generic construction worker, and I need to put him back the way he was. Now, where is Xacto knife? [as Emmet lies on the table]
Emmet Brickowoski: I gotta get the Piece of Resistance. If I could get the attention of the smaller creature. I gotta move.
[Finn's father continues to look for his knife]
The Man Upstairs: Where is that? [using all his strength Emmet manages to slightly move on the table catching Finn's father eye, but he quickly dismisses and looks away] Alright.
[Emmet starts to twitch more on the table and everytime he moves Finn's father turns to look at him not sure of what he's seen, as he turns back to look for his knife Emmet tries to move again]
Emmet Brickowoski: Mmmove! [Emmet finally manages to move enough to drop himself off the table] Ow! [this catches Finn's attention]
Finn: Uh, Dad?
The Man Upstairs: Yeah?
Finn: I think I saw the Xacto over there in Middle Zealand.
The Man Upstairs: Oh, great. Thank you.
Finn: Welcome. [as he goes to get the knife Finn quickly goes over and picks Emmet from the floor and hands him the Piece of Resistance] It's up to you now, Emmet.
[Finn then turns and looks at a cat poster with the phrase "Believe" written on it which Emmet also notices, he them remembers what Vitruvius had told him and then suddenly the cat's mouth on the poster starts moving as Vitruvius speaks]
Vitruvius: Believe. I know that sounds like a cat poster, but it's true.
[Finn uses a magic Lego portal that he's built to send Emmet down where Emmet can start moving again and crashes back in Lego world]
Emmet Brickowoski: Sorry, street. [as Emmet start running through the street he notices the different Lego pieces and sees in his mind how he can assemble a fighting machine from the construction site] I can see everything! [he quickly assembles a large fighting machine to join in the battle which the micro-managers notice]
Micro-Manager: What the heck is that?
Emmet Brickowoski: I am a Master Builder!
Lord Business: Release every micro-manager we have!
Micro-Manager: Let's get him, fellas!
[Emmet uses his machine to knock out the micro-managers attacking him, he looks down and waves to his friends]
Emmet Brickowoski: Hey, everyone!
Wyldstyle: Emmet!
Unikitty: We're saved!
Emmet Brickowoski: Lucy, I'm going inside that thing.
Wyldstyle: You got it, Emmet.
Emmet: Huh?
Wyldstle: Wait! Come back!
Metal Beard: Here's how we do it pirate style! [they all join to help Emmet fight off the micro-managers]
Wyldstyle: Emmet, that's it! [as Emmet gets knocked down by one of the micro-mangers Unikitty watches in distress]
Unikitty: Emmet! [she watches as herd of micro-managers surround Emmet in his machine] Stay positive Stay... positive [as he tries to fend off the micro-managers]
Emmet: They're tearing me apart.
Unikitty: Stay... positive..
Emmet: Come on! [unable to keep a positive attitude suddenly Unikitty unleashes her rage]
Unikitty: Oh forget it! You all need to be more friendly. Emmet, go! Go, now's your chance!
Metal Beard: She's right, you can do it, my laddy?
Batman: Go on, kid. Get in there.
[Emmet finally manages to break into Lord Business's aircraft]
Robot:Sir we got an intru-]both robtos get blasted.]
Emmet Brickowoski: Lord Business.
Lord Business: Back from the dead, Brickowoski? Well, you're too late! Skeletrons, get him. [as the skeletal robots start attacking Emmet he quickly fight them off and in the process knocks Lord Business out of his evil suit, Lord Business then uses the Krazy Glue and sprays some on Emmet making one of his legs freeze]
Emmet Brickowoski: I can't move?
[Lord Business does an evil laugh]
Lord Business: You see your friends? Oh, they're finished! And my world is almost finished. [the micro-managers capture Emmet's friends] And the last thing I need to do is finish you. [he walks over to Emmet and points the glue at him]
Emmet Brickowoski: No, stop! Please! If you do one thing and I'm gonna unleash my secret weapon!
Lord Business: Your secret weapon?
Emmet Brickowoski: Yes. It's called "the power of the Special."
Lord Business: That sounds dumb.
Emmet Brickowoski: Alright. Here it comes. My secret weapon...is this. [he holds up his hand]
Lord Business: What is that? Is it super small? I don't see anything.
Emmet Brickowoski: It's my hand. I don't want you to take it.
Lord Business: You don't want me to take your hand?
Emmet Brickowoski: No. I want you to join me. Look at all of these things that people built. [he points to the TV monitors showing the Lego citizens in their various fighting machines] You might see a mess...
Lord Business: Exactly! And a bunch of weird dorky stuff that ruined my perfectly good stuff!
Emmet Brickowoski: Okay. What I see are people inspired by each other, and by you. People taking what you made and making something new out of it. [this serves as a parallel to the real world where Finn's father looks at the Lego pieces Finn has assembled together]
The Man Upstairs: Finn, did you make all of this?
Finn: The people are trying to stop President Business from using the Kragle.
The Man Upstairs: What's the Kragle?
Finn: Um...it's in there. [he points to the big black box which is Lord Business's aircraft]
The Man Upstairs: In here? [Finn's father opens the top of the aircraft and takes out Lord Business, he then looks around the room where he's put up "Do Not Touch" signs all over the Lego pieces he'd built] So President Business is the bad guy? [Finn doesn't reply and looks down] If the construction guy... said something to President Business... what would he say? [back in the Lego world Emmet delivers his speech to Lord Business]
Emmet Brickowoski: You...don't have to be the bad guy. You are the most talented, most interesting and extraordinary person in the universe. And you are capable of amazing things, because you are the Special. [Lord Business looks shocked and lowers the Kragle] And so am I. And so is everyone. The prophecy is made up, but it's also true. It's about all of us. Right now, it's about you. And you still can change everything. [he holds up the Piece of Resistance, Lord Business drops the Kragle and starts walking over to Emmet, back in the real world Finn's father hugs Finn, at the same time in Lego world we see Lord Business is hugging Emmet] Oh, we got a hugger. [Emmet hands the Piece of Resistance to Lord Business] Be careful. I have been told it might explode.
[Lord Business winks at Emmet, makes his way to the Kragle, in the real world Finn's father places the lid on the Krazy Glue, at the same time Lord Business places the Piece of Resistance on to the Kragle and into the TAKO device]
Lord Business: Emmet, thank you. And I just want you to know, from the bottom of my heart, from this moment forward, I solemnly promise that I will never... [suddenly the Kragle explodes causing all the micro-managers to die, Emmet lands in the middle of the city where his friends are]
Benny: Emmet!
Metal Beard: Emmet!
Batman: Emmet!
Unikitty: Hi!
Emmet Brickowoski: Hey, everyone!
Unikitty: Yay!
Emmet Brickowoski: Is everyone okay? Where's Lucy?
[Wyldstyle comes up from under a micro-manager]
Wyldstyle: Emmet!
Emmet Brickowoski: Lucy!
[Emmet rushes over to her and Wyldstyle jumps into his arms]
Wyldstyle: We did it. [just as they are about to hold hands Batman interrupts them] Oh, um. Emmet, wait. Batman, there's something I need to say to you.
Batman: No, Wyldstyle. I mean...Lucy. [he points to Emmet] He's the hero you deserve.
Wyldstyle: [Wyldstyle smiles and Emmet looks behind him to see who Batman was pointing at] Thanks, Batman.
[Wyldstyle turns Emmet's face towards her and they finally holds hands, everyone cheers for them, then we see Vitruvius's ghostly form hovering over the city watching them]
Vitruvius: I liked Emmet before he was cool. [we see Lord Business is pouring an antidote to unstick everybody]
Lord Business: Whoops, I have the antidote for the Kragle. How did that happen? [at the same time in the real world Finn's father is pouring glue remover all over the Lego pieces as Finn watches]
Finn: De-kragler.
The Man Upstairs: What's this? Yay! [as Finn's father pours glue remover onto Pa and Ma Cop Finn reunites Bad Cop with his parents]
Finn: Oh, Mommy, Daddy, you're okay!
Ma Cop: Oh, son!
[Bad Cop who's now using his drawn on Good Cop face hugs his parents]
Good Cop: Hi, Mom. Hi, Dad.
Pa Cop: We're okay, son. [in the real world as Finn and his father are playing with the Lego pieces Finn's mother calls out]
Finn's Mother: Hey, guys? Time to come up for dinner! It's Taco Tuesday, your favorite!
The Man Upstairs: Okay, honey! We'll be up in a sec!
Finn: Yeah, we'll be up in a sec!
The Man Upstairs: I gotta tell you something.
Finn: What?
The Man Upstairs: Now that I'm letting you come down here and play, guess who else gets to come down here and play?
Finn: Who?
The Man Upstairs: Your sister.
Finn: What?
[last lines; as everyone in the Lego world is celebrating]
Emmet Brickowoski: Well, things sure have a way of working out smoothly. Am I right, guys? [suddenly and alien spaceship hovers above them]
Metal Beard: Whaaaaa...? [a trio of Duplo alien figures descend into Lego world]
Duplo: We are from the planet Duplon, and we are here to destroy you.
Emmet Brickowoski: Oh, man.
[End of The Lego Movie]